import { useState, useRef, useEffect } from "react";

type Screen =
  | "dashboard" | "projects" | "settings" | "new-check" | "analysis" | "results"
  | "issues" | "fix-preview" | "fix-processing" | "fix-results"
  | "brand-kit" | "product-library" | "history";

// ─── Tokens ───────────────────────────────────────────────────────────────────
const c = {
  red: "#dc2626", redLight: "#fee2e2", redDark: "#991b1b",
  amber: "#d97706", amberLight: "#fef3c7", amberDark: "#92400e",
  green: "#16a34a", greenLight: "#dcfce7", greenDark: "#166534",
  blue: "#2563eb", blueLight: "#eff6ff",
  border: "#e5e7eb", borderDark: "#d1d5db",
  bg: "#ffffff", bgAlt: "#f9fafb", bgTer: "#f3f4f6",
  text: "#111827", textSec: "#6b7280", textTer: "#9ca3af",
  shadow: "0 1px 3px rgba(0,0,0,0.08), 0 1px 2px rgba(0,0,0,0.04)",
  shadowMd: "0 4px 12px rgba(0,0,0,0.08), 0 2px 4px rgba(0,0,0,0.04)",
};

// ─── Primitives ───────────────────────────────────────────────────────────────
function Card({ children, style }: { children: React.ReactNode; style?: React.CSSProperties }) {
  return (
    <div style={{ background: c.bg, border: `1px solid ${c.border}`, borderRadius: 10, padding: 20, boxShadow: c.shadow, ...style }}>
      {children}
    </div>
  );
}

function Badge({ children, variant }: { children: React.ReactNode; variant: "red" | "amber" | "green" | "blue" | "gray" }) {
  const map = {
    red:   { bg: c.redLight,   color: c.redDark },
    amber: { bg: c.amberLight, color: c.amberDark },
    green: { bg: c.greenLight, color: c.greenDark },
    blue:  { bg: c.blueLight,  color: c.blue },
    gray:  { bg: c.bgTer,      color: c.textSec },
  };
  const s = map[variant];
  return (
    <span style={{ background: s.bg, color: s.color, padding: "2px 8px", borderRadius: 20, fontSize: 11, fontWeight: 600, display: "inline-flex", alignItems: "center", gap: 3, letterSpacing: "0.01em" }}>
      {children}
    </span>
  );
}

function Btn({ children, variant = "primary", onClick, disabled, small, fullWidth }: {
  children: React.ReactNode; variant?: "primary" | "secondary" | "danger" | "ghost";
  onClick?: () => void; disabled?: boolean; small?: boolean; fullWidth?: boolean;
}) {
  const styles: Record<string, React.CSSProperties> = {
    primary:   { background: "#111827", color: "#fff", border: "none", boxShadow: "0 1px 2px rgba(0,0,0,0.15)" },
    secondary: { background: c.bg, color: c.text, border: `1px solid ${c.border}`, boxShadow: c.shadow },
    danger:    { background: c.red, color: "#fff", border: "none" },
    ghost:     { background: "transparent", color: c.textSec, border: `1px solid ${c.border}` },
  };
  return (
    <button disabled={disabled} onClick={onClick} style={{
      ...styles[variant], fontFamily: "var(--font-sans)", fontWeight: 500,
      fontSize: small ? 12 : 13, padding: small ? "5px 12px" : "8px 16px",
      borderRadius: 7, cursor: disabled ? "not-allowed" : "pointer",
      opacity: disabled ? 0.4 : 1, display: "inline-flex", alignItems: "center",
      justifyContent: "center", gap: 5, whiteSpace: "nowrap",
      width: fullWidth ? "100%" : undefined, letterSpacing: "0.01em",
      transition: "opacity 0.1s",
    }}>{children}</button>
  );
}

function Toggle({ on, onChange }: { on: boolean; onChange: (v: boolean) => void }) {
  return (
    <button onClick={() => onChange(!on)} style={{ width: 38, height: 21, borderRadius: 11, border: "none", cursor: "pointer", background: on ? "#111827" : c.bgTer, position: "relative", transition: "background 0.18s", flexShrink: 0, padding: 0 }}>
      <div style={{ width: 15, height: 15, borderRadius: "50%", background: "#fff", position: "absolute", top: 3, left: on ? 20 : 3, transition: "left 0.18s", boxShadow: "0 1px 3px rgba(0,0,0,0.2)" }} />
    </button>
  );
}

function Divider({ style }: { style?: React.CSSProperties }) {
  return <hr style={{ border: "none", borderTop: `1px solid ${c.border}`, margin: "12px 0", ...style }} />;
}

function Toast({ msg }: { msg: string }) {
  return (
    <div className="anim-fade" style={{ position: "fixed", bottom: 28, left: "50%", transform: "translateX(-50%)", background: "#111827", color: "#fff", padding: "10px 20px", borderRadius: 8, fontSize: 13, fontWeight: 500, zIndex: 9999, display: "flex", alignItems: "center", gap: 8, boxShadow: c.shadowMd }}>
      <span style={{ color: c.green }}>✓</span> {msg}
    </div>
  );
}

function useSave(msg = "Changes saved") {
  const [saved, setSaved] = useState(false);
  function save() { setSaved(true); setTimeout(() => setSaved(false), 2200); }
  return { saved, save, msg };
}

// ─── SVG helpers ──────────────────────────────────────────────────────────────
function Sparkline({ values, color, width = 72, height = 24 }: { values: number[]; color: string; width?: number; height?: number }) {
  const max = Math.max(...values), min = Math.min(...values), range = max - min || 1;
  const xs = values.map((_, i) => (i / (values.length - 1)) * width);
  const ys = values.map(v => height - ((v - min) / range) * (height * 0.75) - height * 0.12);
  return (
    <svg width={width} height={height} style={{ display: "block" }}>
      <polyline points={xs.map((x, i) => `${x},${ys[i]}`).join(" ")} fill="none" stroke={color} strokeWidth={1.5} strokeLinejoin="round" strokeLinecap="round" />
    </svg>
  );
}

function ScoreRing({ score, size = 76 }: { score: number; size?: number }) {
  const r = size * 0.38, cx = size / 2, cy = size / 2;
  const circ = 2 * Math.PI * r, dash = (score / 100) * circ;
  const color = score >= 85 ? c.green : score >= 70 ? c.amber : c.red;
  return (
    <svg width={size} height={size}>
      <circle cx={cx} cy={cy} r={r} fill="none" stroke={c.bgTer} strokeWidth={5} />
      <circle cx={cx} cy={cy} r={r} fill="none" stroke={color} strokeWidth={5}
        strokeDasharray={`${dash} ${circ - dash}`} strokeDashoffset={circ / 4} strokeLinecap="round" />
      <text x={cx} y={cy + 5} textAnchor="middle" fontSize={size * 0.19} fontWeight={700} fontFamily="var(--font-mono)" fill={color}>{score}</text>
    </svg>
  );
}

function ScoreBar({ label, score, weight }: { label: string; score: number; weight: string }) {
  const color = score >= 85 ? c.green : score >= 70 ? c.amber : c.red;
  return (
    <div style={{ marginBottom: 10 }}>
      <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 5 }}>
        <span style={{ fontSize: 12, color: c.textSec }}>{label} <span style={{ fontSize: 10, color: c.textTer }}>({weight})</span></span>
        <span style={{ fontSize: 12, fontWeight: 700, fontFamily: "var(--font-mono)", color }}>{score}</span>
      </div>
      <div style={{ height: 4, background: c.bgTer, borderRadius: 3 }}>
        <div style={{ width: `${score}%`, height: "100%", borderRadius: 3, background: color }} />
      </div>
    </div>
  );
}

// ─── File Drop Zone ───────────────────────────────────────────────────────────
function DropZone({ label, hint, multiple, files, onFiles, onClear, compact }: {
  label: string; hint: string; multiple?: boolean;
  files: string[]; onFiles: (names: string[]) => void; onClear: () => void; compact?: boolean;
}) {
  const inputRef = useRef<HTMLInputElement>(null);
  const [dragging, setDragging] = useState(false);

  function handleDrop(e: React.DragEvent) {
    e.preventDefault(); setDragging(false);
    const names = Array.from(e.dataTransfer.files).map(f => `${f.name} (${(f.size / 1048576).toFixed(1)} MB)`);
    onFiles(multiple ? names : [names[0]]);
  }
  function handleChange(e: React.ChangeEvent<HTMLInputElement>) {
    const names = Array.from(e.target.files ?? []).map(f => `${f.name} (${(f.size / 1048576).toFixed(1)} MB)`);
    onFiles(multiple ? names : [names[0]]);
    e.target.value = "";
  }

  return (
    <div>
      <input ref={inputRef} type="file" multiple={multiple} accept="image/*" style={{ display: "none" }} onChange={handleChange} />
      <div
        onClick={() => inputRef.current?.click()}
        onDragOver={e => { e.preventDefault(); setDragging(true); }}
        onDragLeave={() => setDragging(false)}
        onDrop={handleDrop}
        style={{ border: `1.5px dashed ${dragging ? "#111827" : c.borderDark}`, borderRadius: 8, padding: compact ? "20px 16px" : "32px 20px", textAlign: "center", cursor: "pointer", background: dragging ? c.bgAlt : c.bg, transition: "all 0.12s" }}
      >
        <div style={{ fontSize: compact ? 22 : 28, marginBottom: 8 }}>
          <svg width={compact ? 22 : 28} height={compact ? 26 : 32} viewBox="0 0 24 28" fill="none" style={{ display: "inline-block" }}>
            <rect x="3" y="1" width="14" height="19" rx="2" stroke={c.textTer} strokeWidth="1.5" fill={c.bgAlt}/>
            <path d="M13 1v5h7" stroke={c.textTer} strokeWidth="1.5" strokeLinejoin="round"/>
            <circle cx="16" cy="19" r="6" fill={dragging ? "#111827" : c.bgAlt} stroke={dragging ? "none" : c.borderDark} strokeWidth="1.2"/>
            <path d="M16 16v6M13 19h6" stroke={dragging ? "#fff" : c.textSec} strokeWidth="1.4" strokeLinecap="round"/>
          </svg>
        </div>
        <div style={{ fontWeight: 600, fontSize: compact ? 13 : 14, marginBottom: 4, color: c.text }}>{label}</div>
        <div style={{ fontSize: 12, color: c.textSec, whiteSpace: "pre-line", lineHeight: 1.5 }}>{hint}</div>
      </div>
      {files.length > 0 && (
        <div style={{ marginTop: 10, background: c.bgAlt, borderRadius: 7, border: `1px solid ${c.border}`, overflow: "hidden" }}>
          {files.map((f, i) => (
            <div key={i} style={{ display: "flex", alignItems: "center", gap: 8, padding: "8px 12px", fontSize: 12, color: c.textSec, borderBottom: i < files.length - 1 ? `1px solid ${c.border}` : "none" }}>
              <span style={{ color: c.green, fontSize: 14 }}>✓</span>
              <span style={{ flex: 1, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{f}</span>
            </div>
          ))}
          <div style={{ padding: "8px 12px" }}>
            <Btn variant="ghost" small onClick={onClear}>Remove</Btn>
          </div>
        </div>
      )}
    </div>
  );
}

// ─── Shared data ──────────────────────────────────────────────────────────────
const ALL_CHECKS = [
  { id: 1, name: "Travel Campaign",   score: 84, status: "warning",  issues: 3, date: "Sep 2",  brand: "Nomad Studio",   campaign: "Travel Q4" },
  { id: 2, name: "Summer Launch",     score: 93, status: "ready",    issues: 0, date: "Sep 1",  brand: "Nomad Studio",   campaign: "Summer" },
  { id: 3, name: "Facebook Ad #12",   score: 67, status: "critical", issues: 5, date: "Aug 31", brand: "Luxe Brand Co.", campaign: "Retargeting" },
  { id: 4, name: "Instagram Post",    score: 78, status: "warning",  issues: 2, date: "Aug 30", brand: "Nomad Studio",   campaign: "Travel Q4" },
  { id: 5, name: "Product Hero Shot", score: 91, status: "ready",    issues: 0, date: "Aug 29", brand: "Minimal Co.",    campaign: "Brand" },
  { id: 6, name: "Banner Ad Set",     score: 72, status: "warning",  issues: 1, date: "Aug 28", brand: "Luxe Brand Co.", campaign: "Retargeting" },
];

const PROJECTS = [
  { name: "Travel Q4",   checks: 4, ready: 2, avgScore: 81, lastActivity: "Sep 2" },
  { name: "Summer",      checks: 1, ready: 1, avgScore: 93, lastActivity: "Sep 1" },
  { name: "Retargeting", checks: 2, ready: 0, avgScore: 70, lastActivity: "Aug 31" },
  { name: "Brand",       checks: 2, ready: 2, avgScore: 90, lastActivity: "Aug 27" },
];

const BRANDS_DATA = [
  { name: "Nomad Studio",   products: 2, style: "Editorial, Premium, Travel", colors: ["#D4AF37","#1A1F36","#F5F1ED"] },
  { name: "Luxe Brand Co.", products: 1, style: "Luxury, Minimal, Dark",      colors: ["#B8860B","#0a0a0a","#F0EEE8"] },
  { name: "Minimal Co.",    products: 3, style: "Minimal, Clean, Bold",        colors: ["#111111","#ffffff","#F5F5F5"] },
];

// ─── Sidebar ──────────────────────────────────────────────────────────────────
function NavBtn({ item, active, onNav }: { item: { id: string; label: string; icon: string }; active: Screen; onNav: (s: Screen) => void }) {
  const isActive =
    active === item.id ||
    (item.id === "history" && (active === "results" || active === "issues" || active === "fix-preview" || active === "fix-processing" || active === "fix-results"));
  return (
    <button onClick={() => onNav(item.id as Screen)} style={{
      width: "100%", display: "flex", alignItems: "center", gap: 8,
      padding: "6px 10px", borderRadius: 6, border: "none", cursor: "pointer",
      fontFamily: "var(--font-sans)", fontSize: 13, fontWeight: isActive ? 600 : 400,
      background: isActive ? c.bgTer : "transparent",
      color: isActive ? c.text : c.textSec, textAlign: "left", marginBottom: 1,
    }}>
      <span style={{ fontSize: 13, width: 16, textAlign: "center", flexShrink: 0, opacity: isActive ? 1 : 0.6 }}>{item.icon}</span>
      {item.label}
    </button>
  );
}

function Sidebar({ active, onNav }: { active: Screen; onNav: (s: Screen) => void }) {
  const RECENT_PROJECTS = PROJECTS.slice(0, 3);

  return (
    <aside style={{ width: 216, minWidth: 216, background: c.bg, borderRight: `1px solid ${c.border}`, display: "flex", flexDirection: "column", height: "100%", overflowY: "auto" }}>
      {/* Logo */}
      <div style={{ padding: "14px 14px 10px", flexShrink: 0 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
          <div style={{ width: 28, height: 28, background: "#111827", borderRadius: 7, display: "flex", alignItems: "center", justifyContent: "center", color: "#fff", fontSize: 12, fontWeight: 800, flexShrink: 0 }}>V</div>
          <div>
            <div style={{ fontWeight: 700, fontSize: 13, letterSpacing: -0.3, color: c.text }}>VERITY</div>
            <div style={{ fontSize: 10, color: c.textTer }}>Creative QA Platform</div>
          </div>
        </div>
      </div>

      {/* New Check CTA */}
      <div style={{ padding: "6px 10px 10px", flexShrink: 0 }}>
        <button onClick={() => onNav("new-check")} style={{ width: "100%", display: "flex", alignItems: "center", gap: 7, padding: "7px 12px", background: "#111827", color: "#fff", border: "none", borderRadius: 7, cursor: "pointer", fontFamily: "var(--font-sans)", fontWeight: 600, fontSize: 13 }}>
          <span style={{ fontSize: 15, lineHeight: 1 }}>+</span> New Check
        </button>
      </div>

      {/* All nav items grouped */}
      <nav style={{ padding: "0 8px", flexShrink: 0 }}>
        <NavBtn item={{ id: "dashboard",       label: "Home",            icon: "⌂" }} active={active} onNav={onNav} />
        <NavBtn item={{ id: "projects",        label: "Projects",        icon: "▦" }} active={active} onNav={onNav} />
        <NavBtn item={{ id: "history",         label: "Recent Checks",   icon: "≡" }} active={active} onNav={onNav} />
        <NavBtn item={{ id: "brand-kit",       label: "Brand Kit",       icon: "◈" }} active={active} onNav={onNav} />
        <NavBtn item={{ id: "product-library", label: "Product Library", icon: "⬡" }} active={active} onNav={onNav} />
        <NavBtn item={{ id: "settings",        label: "Settings",        icon: "⚙" }} active={active} onNav={onNav} />
      </nav>

      <Divider style={{ margin: "10px 10px 4px" }} />

      {/* Recent Projects */}
      <div style={{ padding: "0 10px 4px", flexShrink: 0 }}>
        <div style={{ fontSize: 10, fontWeight: 600, color: c.textTer, letterSpacing: "0.08em", textTransform: "uppercase", padding: "0 4px", marginBottom: 6 }}>Recent Projects</div>
        {RECENT_PROJECTS.map(p => {
          const dotColor = p.ready === p.checks ? c.green : p.ready === 0 ? c.red : c.amber;
          return (
            <button key={p.name} onClick={() => onNav("projects")} style={{ width: "100%", display: "flex", alignItems: "center", gap: 8, padding: "5px 8px", borderRadius: 6, border: "none", cursor: "pointer", background: "transparent", fontFamily: "var(--font-sans)", marginBottom: 1 }}>
              <div style={{ width: 6, height: 6, borderRadius: "50%", background: dotColor, flexShrink: 0 }} />
              <span style={{ fontSize: 12, color: c.textSec, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap", flex: 1, textAlign: "left" }}>{p.name}</span>
              <span style={{ fontSize: 10, color: c.textTer, flexShrink: 0 }}>{p.checks}</span>
            </button>
          );
        })}
      </div>

      <div style={{ flex: 1 }} />

      {/* User */}
      <div style={{ padding: "8px 12px 12px", borderTop: `1px solid ${c.border}`, flexShrink: 0 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
          <div style={{ width: 26, height: 26, background: "#111827", borderRadius: "50%", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 10, fontWeight: 700, color: "#fff", flexShrink: 0 }}>JD</div>
          <div style={{ flex: 1, minWidth: 0 }}>
            <div style={{ fontWeight: 500, fontSize: 12, color: c.text, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>Jane Doe</div>
            <div style={{ color: c.textTer, fontSize: 10 }}>12 / 100 checks used</div>
          </div>
        </div>
      </div>
    </aside>
  );
}

// ─── Screen 1: Dashboard Home ─────────────────────────────────────────────────
function Dashboard({ onNav }: { onNav: (s: Screen) => void }) {
  return (
    <div style={{ flex: 1, overflow: "auto", background: c.bg, display: "flex", flexDirection: "column" }}>
      <TabHome onNav={onNav} />
    </div>
  );
}

// ─── Dashboard Home — ChatGPT style ──────────────────────────────────────────
function TabHome({ onNav }: { onNav: (s: Screen) => void }) {
  const inputRef = useRef<HTMLInputElement>(null);
  const [adFile, setAdFile] = useState<string[]>([]);
  const [brand, setBrand] = useState("");
  const [dragging, setDragging] = useState(false);
  const [showConfig, setShowConfig] = useState(false);

  function handleDrop(e: React.DragEvent) {
    e.preventDefault(); setDragging(false);
    const names = Array.from(e.dataTransfer.files).map(f => `${f.name} (${(f.size / 1048576).toFixed(1)} MB)`);
    if (names[0]) { setAdFile([names[0]]); setShowConfig(true); }
  }
  function handleChange(e: React.ChangeEvent<HTMLInputElement>) {
    const names = Array.from(e.target.files ?? []).map(f => `${f.name} (${(f.size / 1048576).toFixed(1)} MB)`);
    if (names[0]) { setAdFile([names[0]]); setShowConfig(true); }
    e.target.value = "";
  }

  const QUICK = [
    { label: "Check travel ad", icon: "✈️", brand: "Nomad Studio" },
    { label: "Verify product shot", icon: "📷", brand: "Minimal Co." },
    { label: "Review luxury creative", icon: "💎", brand: "Luxe Brand Co." },
    { label: "Brand consistency check", icon: "◈", brand: "Nomad Studio" },
  ];

  const hasFile = adFile.length > 0;
  const hasBrand = !!brand;
  const STEPS_FLOW = [
    { label: "Upload",    done: hasFile },
    { label: "Classify",  done: hasFile && hasBrand, active: hasFile && !hasBrand },
    { label: "Configure", done: hasFile && hasBrand, active: false },
    { label: "Extract",   done: false },
    { label: "Complete",  done: false },
  ];

  return (
    <div style={{ flex: 1, display: "flex", flexDirection: "column", minHeight: 0 }}>
      <input ref={inputRef} type="file" accept="image/*" style={{ display: "none" }} onChange={handleChange} />

      {/* Center area */}
      <div style={{ flex: 1, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", padding: "32px 32px 24px" }}>

        {/* Greeting */}
        <div style={{ textAlign: "center", marginBottom: 24 }}>
          <div style={{ fontSize: 26, fontWeight: 700, color: c.text, letterSpacing: -0.5, marginBottom: 5 }}>
            What are we checking today?
          </div>
          <div style={{ fontSize: 14, color: c.textSec }}>Upload your creative and get a quality score in seconds.</div>
        </div>

        {/* Upload card */}
        <div style={{ width: "100%", maxWidth: 600 }}>
          {/* Step progress bar */}
          <div style={{ display: "flex", alignItems: "center", justifyContent: "center", gap: 0, marginBottom: 16 }}>
            {STEPS_FLOW.map((step, i) => (
              <div key={step.label} style={{ display: "flex", alignItems: "center" }}>
                {i > 0 && <div style={{ width: 28, height: 1.5, background: step.done ? c.green : c.border }} />}
                <div style={{ display: "flex", alignItems: "center", gap: 5 }}>
                  {step.done ? (
                    <div style={{ width: 20, height: 20, borderRadius: "50%", background: c.green, display: "flex", alignItems: "center", justifyContent: "center" }}>
                      <svg width="10" height="10" viewBox="0 0 10 10" fill="none"><path d="M2 5l2.5 2.5L8 3" stroke="#fff" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"/></svg>
                    </div>
                  ) : (
                    <div style={{ width: 20, height: 20, borderRadius: "50%", background: step.active ? "#111827" : c.bgTer, border: `1.5px solid ${step.active ? "#111827" : c.border}`, display: "flex", alignItems: "center", justifyContent: "center" }}>
                      <span style={{ fontSize: 9, fontWeight: 700, color: step.active ? "#fff" : c.textTer }}>{i + 1}</span>
                    </div>
                  )}
                  <span style={{ fontSize: 11, fontWeight: step.done ? 500 : step.active ? 600 : 400, color: step.done ? c.green : step.active ? c.text : c.textTer }}>{step.label}</span>
                </div>
              </div>
            ))}
          </div>

          {/* Drop zone */}
          <div
            onDragOver={e => { e.preventDefault(); setDragging(true); }}
            onDragLeave={() => setDragging(false)}
            onDrop={handleDrop}
            style={{ border: `1.5px solid ${dragging ? "#111827" : c.border}`, borderRadius: 14, overflow: "hidden", background: dragging ? c.bgAlt : c.bg, boxShadow: "0 2px 16px rgba(0,0,0,0.06)", transition: "all 0.15s" }}
          >
            {adFile.length === 0 ? (
              <div onClick={() => inputRef.current?.click()} style={{ padding: "40px 32px", textAlign: "center", cursor: "pointer" }}>
                <div style={{ width: 48, height: 48, borderRadius: 12, background: c.bgAlt, border: `1px solid ${c.border}`, display: "flex", alignItems: "center", justifyContent: "center", margin: "0 auto 14px" }}>
                  <svg width="22" height="22" viewBox="0 0 22 22" fill="none">
                    <path d="M11 14V5M11 5L8 8M11 5L14 8" stroke={c.textSec} strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
                    <path d="M3 15v2a2 2 0 002 2h12a2 2 0 002-2v-2" stroke={c.textSec} strokeWidth="1.5" strokeLinecap="round"/>
                  </svg>
                </div>
                <div style={{ fontSize: 15, fontWeight: 600, color: c.text, marginBottom: 5 }}>Drop your creative here</div>
                <div style={{ fontSize: 13, color: c.textTer }}>or <span style={{ color: "#111827", fontWeight: 500 }}>click to browse</span> — JPG, PNG, max 10 MB</div>
              </div>
            ) : (
              <div style={{ padding: "14px 20px", display: "flex", alignItems: "center", gap: 12 }}>
                <div style={{ width: 36, height: 36, borderRadius: 8, background: c.greenLight, display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>
                  <svg width="16" height="16" viewBox="0 0 16 16" fill="none"><path d="M3 8l3.5 3.5L13 4" stroke={c.green} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/></svg>
                </div>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ fontSize: 13, fontWeight: 500, color: c.text, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{adFile[0]}</div>
                  <div style={{ fontSize: 11, color: c.textTer, marginTop: 1 }}>Ready to analyze</div>
                </div>
                <button onClick={() => { setAdFile([]); setShowConfig(false); setBrand(""); }} style={{ background: "transparent", border: "none", cursor: "pointer", color: c.textTer, fontSize: 18, lineHeight: 1, padding: "2px 6px" }}>×</button>
              </div>
            )}

            {showConfig && (
              <div style={{ borderTop: `1px solid ${c.border}`, padding: "12px 20px", display: "flex", alignItems: "center", gap: 10, background: c.bgAlt }}>
                <select value={brand} onChange={e => setBrand(e.target.value)} style={{ flex: 1, padding: "7px 10px", border: `1px solid ${c.border}`, borderRadius: 7, fontFamily: "var(--font-sans)", fontSize: 13, background: c.bg, color: brand ? c.text : c.textTer, outline: "none" }}>
                  <option value="">Select brand profile…</option>
                  {BRANDS_DATA.map(b => <option key={b.name} value={b.name}>{b.name}</option>)}
                </select>
                <button disabled={!brand} onClick={() => onNav("analysis")} style={{ background: brand ? "#111827" : c.bgTer, color: brand ? "#fff" : c.textTer, border: "none", borderRadius: 7, padding: "7px 20px", fontFamily: "var(--font-sans)", fontSize: 13, fontWeight: 600, cursor: brand ? "pointer" : "not-allowed", whiteSpace: "nowrap", transition: "background 0.15s" }}>
                  Analyze →
                </button>
              </div>
            )}
          </div>

          {/* Quick chips */}
          {adFile.length === 0 && (
            <div style={{ display: "flex", gap: 7, marginTop: 14, justifyContent: "center", flexWrap: "wrap" }}>
              {QUICK.map(q => (
                <button key={q.label} onClick={() => { setBrand(q.brand); inputRef.current?.click(); }}
                  style={{ display: "flex", alignItems: "center", gap: 5, padding: "6px 13px", border: `1px solid ${c.border}`, borderRadius: 20, background: c.bg, fontFamily: "var(--font-sans)", fontSize: 12, color: c.textSec, cursor: "pointer" }}
                  onMouseEnter={e => { e.currentTarget.style.background = c.bgAlt; e.currentTarget.style.color = c.text; }}
                  onMouseLeave={e => { e.currentTarget.style.background = c.bg; e.currentTarget.style.color = c.textSec; }}
                >
                  <span>{q.icon}</span>{q.label}
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Recent checks — in content area below upload */}
        <div style={{ width: "100%", maxWidth: 600, marginTop: 32 }}>
          <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 10 }}>
            <span style={{ fontSize: 11, fontWeight: 600, color: c.textTer, letterSpacing: "0.07em", textTransform: "uppercase" }}>Recent Checks</span>
            <button onClick={() => onNav("history")} style={{ background: "transparent", border: "none", fontSize: 12, color: c.textSec, cursor: "pointer", fontFamily: "var(--font-sans)" }}>View all →</button>
          </div>
          <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
            {ALL_CHECKS.slice(0, 4).map(r => (
              <div key={r.id} onClick={() => onNav("results")} style={{ display: "flex", alignItems: "center", gap: 12, padding: "10px 14px", background: c.bg, border: `1px solid ${c.border}`, borderRadius: 10, cursor: "pointer", boxShadow: c.shadow, transition: "border-color 0.1s" }}
                onMouseEnter={e => (e.currentTarget.style.borderColor = c.borderDark)}
                onMouseLeave={e => (e.currentTarget.style.borderColor = c.border)}
              >
                <div style={{ width: 36, height: 36, borderRadius: 8, background: r.status === "ready" ? c.greenLight : r.status === "warning" ? c.amberLight : c.redLight, display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>
                  <span style={{ fontSize: 12, fontWeight: 700, color: r.status === "ready" ? c.green : r.status === "warning" ? c.amber : c.red }}>{r.score}</span>
                </div>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ fontSize: 13, fontWeight: 500, color: c.text }}>{r.name}</div>
                  <div style={{ fontSize: 11, color: c.textTer }}>{r.brand} · {r.date}</div>
                </div>
                <div>
                  {r.status === "ready"    && <Badge variant="green">Ready</Badge>}
                  {r.status === "warning"  && <Badge variant="amber">⚠ {r.issues} issues</Badge>}
                  {r.status === "critical" && <Badge variant="red">Fix needed</Badge>}
                </div>
                <span style={{ color: c.textTer, fontSize: 13 }}>›</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

// ─── Dashboard Projects Tab ───────────────────────────────────────────────────
function TabProjects({ onNav }: { onNav: (s: Screen) => void }) {
  const [selected, setSelected] = useState<string | null>(null);
  const projectChecks = selected ? ALL_CHECKS.filter(r => r.campaign === selected) : [];

  return (
    <div style={{ maxWidth: 900 }}>
      {!selected ? (
        <div>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 6 }}>
            <div>
              <div style={{ fontWeight: 700, fontSize: 20, color: c.text, letterSpacing: -0.3 }}>Projects</div>
              <div style={{ fontSize: 13, color: c.textSec, marginTop: 2 }}>Organise your creatives by campaign</div>
            </div>
            <Btn onClick={() => onNav("new-check")}>+ New Check</Btn>
          </div>
          <Divider style={{ margin: "16px 0" }} />
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(200px, 1fr))", gap: 12 }}>
            {PROJECTS.map(p => (
              <div key={p.name} onClick={() => setSelected(p.name)} style={{ background: c.bg, border: `1px solid ${c.border}`, borderRadius: 10, padding: 16, cursor: "pointer", boxShadow: c.shadow, transition: "box-shadow 0.1s" }}
                onMouseEnter={e => (e.currentTarget.style.boxShadow = c.shadowMd)}
                onMouseLeave={e => (e.currentTarget.style.boxShadow = c.shadow)}
              >
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 10 }}>
                  <div style={{ fontWeight: 600, fontSize: 13, color: c.text }}>{p.name}</div>
                  <Badge variant={p.ready === p.checks ? "green" : p.ready === 0 ? "red" : "amber"}>{p.ready}/{p.checks}</Badge>
                </div>
                <div style={{ fontSize: 12, color: c.textSec, marginBottom: 4 }}>Avg <span style={{ fontFamily: "var(--font-mono)", fontWeight: 600, color: c.text }}>{p.avgScore}</span>/100</div>
                <div style={{ fontSize: 11, color: c.textTer }}>Last: {p.lastActivity}</div>
              </div>
            ))}
            <div onClick={() => onNav("new-check")} style={{ background: c.bg, border: `1.5px dashed ${c.borderDark}`, borderRadius: 10, padding: 16, cursor: "pointer", display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", minHeight: 96 }}>
              <div style={{ fontSize: 20, color: c.textTer, marginBottom: 4 }}>+</div>
              <div style={{ fontSize: 12, color: c.textSec }}>New Project</div>
            </div>
          </div>
        </div>
      ) : (
        <div>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 16 }}>
            <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
              <button onClick={() => setSelected(null)} style={{ background: "transparent", border: `1px solid ${c.border}`, borderRadius: 6, padding: "5px 12px", cursor: "pointer", fontFamily: "var(--font-sans)", fontSize: 12, color: c.textSec }}>← Back</button>
              <div style={{ fontWeight: 600, fontSize: 16, color: c.text }}>{selected}</div>
            </div>
            <Btn small onClick={() => onNav("new-check")}>+ Add Check</Btn>
          </div>
          <Card style={{ padding: 0, overflow: "hidden" }}>
            {projectChecks.length === 0 ? (
              <div style={{ padding: "40px 16px", textAlign: "center", color: c.textTer, fontSize: 13 }}>No creatives in this project yet.</div>
            ) : (
              <table style={{ width: "100%", borderCollapse: "collapse" }}>
                <thead>
                  <tr style={{ background: c.bgAlt }}>
                    {["Creative", "Score", "Status", "Date", ""].map(h => (
                      <th key={h} style={{ padding: "10px 16px", textAlign: "left", fontSize: 11, fontWeight: 600, color: c.textTer, letterSpacing: "0.05em", textTransform: "uppercase", borderBottom: `1px solid ${c.border}` }}>{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {projectChecks.map((row, i) => (
                    <tr key={row.id} style={{ borderBottom: i < projectChecks.length - 1 ? `1px solid ${c.border}` : "none" }}>
                      <td style={{ padding: "10px 16px", fontSize: 13, fontWeight: 500, color: c.text }}>{row.name}</td>
                      <td style={{ padding: "10px 16px" }}>
                        <span style={{ fontFamily: "var(--font-mono)", fontSize: 13, fontWeight: 700, color: row.score >= 85 ? c.green : row.score >= 70 ? c.amber : c.red }}>{row.score}</span>
                      </td>
                      <td style={{ padding: "10px 16px" }}>
                        {row.status === "ready"    && <Badge variant="green">✓ Ready</Badge>}
                        {row.status === "warning"  && <Badge variant="amber">⚠ {row.issues}</Badge>}
                        {row.status === "critical" && <Badge variant="red">Fix needed</Badge>}
                      </td>
                      <td style={{ padding: "10px 16px", color: c.textTer, fontSize: 12 }}>{row.date}</td>
                      <td style={{ padding: "10px 16px" }}><Btn variant="ghost" small onClick={() => onNav("results")}>View</Btn></td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
          </Card>
        </div>
      )}
    </div>
  );
}


// ─── Dashboard Settings Tab ───────────────────────────────────────────────────
function TabSettings() {
  const [notifications, setNotifications] = useState(true);
  const [autoFix, setAutoFix] = useState(false);
  const [threshold, setThreshold] = useState(70);
  const [workspaceName, setWorkspaceName] = useState("My Workspace");
  const { saved, save } = useSave();

  return (
    <div style={{ maxWidth: 560 }}>
      {saved && <Toast msg="Settings saved" />}
      <div style={{ marginBottom: 6 }}>
        <div style={{ fontWeight: 700, fontSize: 20, color: c.text, letterSpacing: -0.3 }}>Settings</div>
        <div style={{ fontSize: 13, color: c.textSec, marginTop: 2 }}>Configure your workspace and preferences</div>
      </div>
      <Divider style={{ margin: "16px 0" }} />
      <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
        <Card>
          <div style={{ fontWeight: 600, fontSize: 13, marginBottom: 14, color: c.text }}>Workspace</div>
          <label style={{ fontSize: 12, fontWeight: 500, color: c.textSec, display: "block", marginBottom: 6 }}>Name</label>
          <input value={workspaceName} onChange={e => setWorkspaceName(e.target.value)} style={{ width: "100%", padding: "8px 12px", border: `1px solid ${c.border}`, borderRadius: 7, fontFamily: "var(--font-sans)", fontSize: 13, outline: "none", boxSizing: "border-box" }} />
        </Card>
        <Card>
          <div style={{ fontWeight: 600, fontSize: 13, marginBottom: 14, color: c.text }}>Analysis</div>
          {[
            { label: "Email notifications", sub: "Get notified when analysis completes", value: notifications, set: setNotifications },
            { label: "Auto-fix on analysis", sub: "Apply fixable issues automatically", value: autoFix, set: setAutoFix },
          ].map(row => (
            <div key={row.label} style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 14 }}>
              <div>
                <div style={{ fontSize: 13, fontWeight: 500, color: c.text }}>{row.label}</div>
                <div style={{ fontSize: 12, color: c.textSec }}>{row.sub}</div>
              </div>
              <Toggle on={row.value} onChange={row.set} />
            </div>
          ))}
          <div>
            <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 5 }}>
              <span style={{ fontSize: 13, fontWeight: 500, color: c.text }}>Publish threshold</span>
              <span style={{ fontFamily: "var(--font-mono)", fontSize: 12, fontWeight: 700, color: c.text }}>{threshold}/100</span>
            </div>
            <input type="range" min={50} max={95} value={threshold} onChange={e => setThreshold(Number(e.target.value))} style={{ width: "100%", accentColor: "#111827" }} />
          </div>
        </Card>
        <div style={{ display: "flex", gap: 8 }}>
          <Btn onClick={save}>Save Changes</Btn>
          <Btn variant="ghost" onClick={() => { setNotifications(true); setAutoFix(false); setThreshold(70); }}>Reset</Btn>
        </div>
      </div>
    </div>
  );
}

// ─── Screen 2: New Check ──────────────────────────────────────────────────────
function NewCheck({ onNav }: { onNav: (s: Screen) => void }) {
  const [step, setStep] = useState(1);
  const [productFiles, setProductFiles] = useState<string[]>([]);
  const [adFiles, setAdFiles] = useState<string[]>([]);
  const [brand, setBrand] = useState("");
  const [campaign, setCampaign] = useState("");

  const STEPS = ["Upload", "Configure", "Analyze"];

  return (
    <div style={{ padding: 28, maxWidth: 860 }}>
      {/* Step indicator */}
      <div style={{ display: "flex", alignItems: "center", gap: 0, marginBottom: 28 }}>
        <button onClick={() => onNav("dashboard")} style={{ background: "transparent", border: `1px solid ${c.border}`, borderRadius: 6, padding: "5px 12px", cursor: "pointer", fontFamily: "var(--font-sans)", fontSize: 12, color: c.textSec, marginRight: 16 }}>← Back</button>
        {STEPS.map((s, i) => {
          const num = i + 1;
          const active = step === num;
          const done = step > num;
          return (
            <div key={s} style={{ display: "flex", alignItems: "center" }}>
              <div style={{ display: "flex", alignItems: "center", gap: 7, padding: "5px 12px", borderRadius: 20, background: active ? "#111827" : done ? c.greenLight : c.bgAlt, border: `1px solid ${active ? "#111827" : done ? "#bbf7d0" : c.border}` }}>
                <span style={{ width: 18, height: 18, borderRadius: "50%", background: active ? "rgba(255,255,255,0.2)" : done ? c.green : c.bgTer, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 11, fontWeight: 700, color: active ? "#fff" : done ? "#fff" : c.textSec }}>{done ? "✓" : num}</span>
                <span style={{ fontSize: 12, fontWeight: 600, color: active ? "#fff" : done ? c.greenDark : c.textSec }}>{s}</span>
              </div>
              {i < STEPS.length - 1 && <div style={{ width: 24, height: 1, background: done ? c.green : c.border, margin: "0 4px" }} />}
            </div>
          );
        })}
      </div>

      {step === 1 && (
        <div>
          <div style={{ fontWeight: 700, fontSize: 20, color: c.text, marginBottom: 4 }}>Upload files</div>
          <div style={{ fontSize: 13, color: c.textSec, marginBottom: 20 }}>Add your product reference photos and the AI-generated ad</div>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16, marginBottom: 20 }}>
            <Card>
              <div style={{ fontWeight: 600, fontSize: 13, marginBottom: 2, color: c.text }}>Product Reference</div>
              <div style={{ fontSize: 12, color: c.textSec, marginBottom: 14 }}>Upload 1–5 photos of your actual product</div>
              <DropZone label="Drop product images" hint={"JPG, PNG · up to 5 files"} multiple files={productFiles} onFiles={n => setProductFiles(p => [...p, ...n].slice(0, 5))} onClear={() => setProductFiles([])} />
            </Card>
            <Card>
              <div style={{ fontWeight: 600, fontSize: 13, marginBottom: 2, color: c.text }}>Ad Creative</div>
              <div style={{ fontSize: 12, color: c.textSec, marginBottom: 14 }}>The AI-generated ad to check</div>
              <DropZone label="Drop your creative" hint={"JPG, PNG · max 10 MB"} files={adFiles} onFiles={n => setAdFiles([n[0]])} onClear={() => setAdFiles([])} />
            </Card>
          </div>
          <Btn disabled={!productFiles.length || !adFiles.length} onClick={() => setStep(2)}>Continue →</Btn>
        </div>
      )}

      {step === 2 && (
        <div style={{ maxWidth: 480 }}>
          <div style={{ fontWeight: 700, fontSize: 20, color: c.text, marginBottom: 4 }}>Configure check</div>
          <div style={{ fontSize: 13, color: c.textSec, marginBottom: 20 }}>Select the brand and campaign this creative belongs to</div>
          <Card style={{ marginBottom: 14 }}>
            <div style={{ marginBottom: 14 }}>
              <label style={{ fontSize: 12, fontWeight: 600, color: c.textSec, display: "block", marginBottom: 7 }}>Brand Profile *</label>
              <select value={brand} onChange={e => setBrand(e.target.value)} style={{ width: "100%", padding: "9px 12px", border: `1px solid ${c.border}`, borderRadius: 7, fontFamily: "var(--font-sans)", fontSize: 13, background: c.bg, outline: "none" }}>
                <option value="">Select brand…</option>
                {BRANDS_DATA.map(b => <option key={b.name} value={b.name}>{b.name}</option>)}
              </select>
            </div>
            <div>
              <label style={{ fontSize: 12, fontWeight: 600, color: c.textSec, display: "block", marginBottom: 7 }}>Campaign <span style={{ fontWeight: 400 }}>(optional)</span></label>
              <select value={campaign} onChange={e => setCampaign(e.target.value)} style={{ width: "100%", padding: "9px 12px", border: `1px solid ${c.border}`, borderRadius: 7, fontFamily: "var(--font-sans)", fontSize: 13, background: c.bg, outline: "none" }}>
                <option value="">Select campaign…</option>
                {PROJECTS.map(p => <option key={p.name}>{p.name}</option>)}
              </select>
            </div>
          </Card>
          <div style={{ display: "flex", gap: 8 }}>
            <Btn variant="ghost" onClick={() => setStep(1)}>← Back</Btn>
            <Btn disabled={!brand} onClick={() => onNav("analysis")}>Run Analysis →</Btn>
          </div>
        </div>
      )}
    </div>
  );
}

// ─── Screen 3: Analysis ───────────────────────────────────────────────────────
const ANALYSIS_STEPS = [
  { label: "Extracting product features",   ms: 900 },
  { label: "Checking brand rules",          ms: 1700 },
  { label: "Validating readability",        ms: 2600 },
  { label: "Generating recommendations",    ms: 3600 },
  { label: "Calculating final score",       ms: 4500 },
];

function Analysis({ onNav }: { onNav: (s: Screen) => void }) {
  const [doneCount, setDoneCount] = useState(0);
  const [finished, setFinished] = useState(false);

  useEffect(() => {
    const timers = ANALYSIS_STEPS.map((s, i) =>
      setTimeout(() => {
        setDoneCount(i + 1);
        if (i === ANALYSIS_STEPS.length - 1) setTimeout(() => setFinished(true), 400);
      }, s.ms)
    );
    return () => timers.forEach(clearTimeout);
  }, []);

  const pct = Math.round((doneCount / ANALYSIS_STEPS.length) * 100);

  return (
    <div style={{ flex: 1, display: "flex", alignItems: "center", justifyContent: "center", padding: 32 }}>
      <Card style={{ width: 460, padding: 32 }}>
        <div style={{ textAlign: "center", marginBottom: 28 }}>
          <div style={{ width: 52, height: 52, borderRadius: "50%", border: `3px solid ${c.border}`, borderTopColor: finished ? c.green : "#111827", margin: "0 auto 16px", ...(finished ? {} : { animation: "spin 0.85s linear infinite" }), display: "flex", alignItems: "center", justifyContent: "center" }} className={finished ? "" : "anim-spin"}>
            {finished && <div style={{ width: 52, height: 52, borderRadius: "50%", border: `3px solid ${c.green}`, display: "flex", alignItems: "center", justifyContent: "center", background: c.greenLight, color: c.green, fontSize: 22 }}>✓</div>}
          </div>
          <div style={{ fontSize: 17, fontWeight: 700, color: c.text, marginBottom: 4 }}>
            {finished ? "Analysis complete!" : "Analyzing your creative…"}
          </div>
          <div style={{ fontSize: 13, color: c.textSec }}>{finished ? "Your results are ready to view" : "Using AI vision to verify product accuracy"}</div>
        </div>

        {/* Progress bar */}
        <div style={{ marginBottom: 8 }}>
          <div style={{ height: 6, background: c.bgTer, borderRadius: 4, overflow: "hidden", marginBottom: 6 }}>
            <div
              className="anim-progress"
              style={{ height: "100%", background: finished ? c.green : "#111827", borderRadius: 4, width: `${pct}%`, transition: "width 0.5s ease, background 0.3s" }}
            />
          </div>
          <div style={{ display: "flex", justifyContent: "space-between", fontSize: 11, color: c.textTer, fontFamily: "var(--font-mono)" }}>
            <span>{ANALYSIS_STEPS[Math.max(0, doneCount - 1)]?.label ?? "Starting…"}</span>
            <span>{pct}%</span>
          </div>
        </div>

        <Divider style={{ margin: "20px 0" }} />

        {/* Step list */}
        <div style={{ display: "flex", flexDirection: "column", gap: 2, marginBottom: 24 }}>
          {ANALYSIS_STEPS.map((s, i) => {
            const done = i < doneCount;
            const active = i === doneCount;
            return (
              <div key={s.label} className={done ? "anim-fade" : ""} style={{ display: "flex", alignItems: "center", gap: 10, padding: "6px 8px", borderRadius: 7, background: active ? c.bgAlt : "transparent" }}>
                <span style={{ width: 18, height: 18, borderRadius: "50%", border: `1.5px solid ${done ? c.green : active ? "#111827" : c.border}`, background: done ? c.green : "transparent", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 10, color: done ? "#fff" : c.textTer, fontWeight: 700, flexShrink: 0, transition: "all 0.2s" }}>
                  {done ? "✓" : active ? <span className="anim-spin" style={{ display: "inline-block", width: 8, height: 8, borderRadius: "50%", border: "1.5px solid #111827", borderTopColor: "transparent" }} /> : i + 1}
                </span>
                <span style={{ fontSize: 13, color: done ? c.text : active ? c.text : c.textTer, fontWeight: done || active ? 500 : 400, transition: "color 0.2s" }}>{s.label}</span>
                {done && <span className="anim-step" style={{ marginLeft: "auto", color: c.green, fontSize: 12 }}>✓</span>}
              </div>
            );
          })}
        </div>

        <Btn fullWidth onClick={() => onNav("results")} disabled={!finished && doneCount < 2}>
          {finished ? "View Results →" : doneCount < 2 ? "Analyzing…" : "Skip to Results →"}
        </Btn>
      </Card>
    </div>
  );
}

// ─── Screen 4: Results ────────────────────────────────────────────────────────
function Results({ onNav }: { onNav: (s: Screen) => void }) {
  const previewInputRef = useRef<HTMLInputElement>(null);
  const downloadLinkRef = useRef<HTMLAnchorElement>(null);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [previewFile, setPreviewFile] = useState<File | null>(null);

  const score = 84;
  const scoreColor = score >= 85 ? c.green : score >= 70 ? c.amber : c.red;

  const breakdown = [
    { label: "Product Accuracy",  score: 91, weight: "35%" },
    { label: "Brand Consistency", score: 96, weight: "25%" },
    { label: "AI Quality",        score: 73, weight: "15%" },
    { label: "Readability",       score: 82, weight: "15%" },
    { label: "Compliance",        score: 88, weight: "10%" },
  ];
  const issues = [
    { sev: "red" as const,   category: "PRODUCT",    title: "Logo differs from approved reference",          fixable: true  },
    { sev: "amber" as const, category: "DESIGN",     title: "CTA becomes difficult to read at mobile size",  fixable: false },
    { sev: "amber" as const, category: "AI QUALITY", title: "Charm connection appears physically impossible", fixable: true  },
  ];

  function handleDownload() {
    if (previewUrl && previewFile) {
      // Download the actual uploaded creative
      const a = downloadLinkRef.current!;
      a.href = previewUrl;
      a.download = previewFile.name || "creative.png";
      a.click();
    } else {
      // Generate and download a plain-text report
      const report = [
        "VERITY — Creative QA Report",
        "================================",
        `Campaign:  Travel Campaign`,
        `Brand:     Nomad Studio`,
        `Date:      Sep 2, 2026`,
        `Score:     ${score}/100`,
        "",
        "SCORE BREAKDOWN",
        "---------------",
        ...breakdown.map(b => `${b.label.padEnd(22)} ${b.score}/100  (weight ${b.weight})`),
        "",
        "ISSUES FOUND",
        "------------",
        ...issues.map((iss, i) => `${i + 1}. [${iss.sev.toUpperCase()}] ${iss.category}: ${iss.title}`),
        "",
        "Verdict: DO NOT PUBLISH — fix critical issues first.",
      ].join("\n");
      const blob = new Blob([report], { type: "text/plain" });
      const url = URL.createObjectURL(blob);
      const a = downloadLinkRef.current!;
      a.href = url;
      a.download = "verity-report-travel-campaign.txt";
      a.click();
      setTimeout(() => URL.revokeObjectURL(url), 1000);
    }
  }

  return (
    <div style={{ padding: "28px 32px", maxWidth: 1020 }}>
      {/* hidden helpers */}
      <input ref={previewInputRef} type="file" accept="image/*" style={{ display: "none" }}
        onChange={e => { const f = e.target.files?.[0]; if (f) { setPreviewUrl(URL.createObjectURL(f)); setPreviewFile(f); } e.target.value = ""; }} />
      {/* eslint-disable-next-line jsx-a11y/anchor-has-content */}
      <a ref={downloadLinkRef} style={{ display: "none" }} />

      {/* ── Header ── */}
      <div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 24 }}>
        <button onClick={() => onNav("dashboard")} style={{ background: "transparent", border: `1px solid ${c.border}`, borderRadius: 7, padding: "6px 13px", cursor: "pointer", fontFamily: "var(--font-sans)", fontSize: 12, color: c.textSec, display: "flex", alignItems: "center", gap: 5 }}>
          ← Dashboard
        </button>
        <div style={{ flex: 1 }}>
          <div style={{ fontWeight: 700, fontSize: 20, color: c.text, letterSpacing: -0.3 }}>Travel Campaign</div>
          <div style={{ fontSize: 12, color: c.textSec, marginTop: 1 }}>Sep 2, 2026 · Nomad Studio</div>
        </div>
        <div style={{ display: "flex", gap: 8 }}>
          <button onClick={handleDownload} style={{ display: "flex", alignItems: "center", gap: 6, padding: "7px 14px", border: `1px solid ${c.border}`, borderRadius: 7, background: c.bg, fontFamily: "var(--font-sans)", fontSize: 13, fontWeight: 500, color: c.text, cursor: "pointer", boxShadow: c.shadow }}>
            <svg width="14" height="14" viewBox="0 0 14 14" fill="none"><path d="M7 2v7M4 6l3 3 3-3" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round"/><path d="M2 11h10" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round"/></svg>
            Download {previewUrl ? "Image" : "Report"}
          </button>
          <Btn variant="secondary" small onClick={() => onNav("issues")}>Full Report</Btn>
          <Btn small onClick={() => onNav("fix-preview")}>Fix Issues</Btn>
        </div>
      </div>

      {/* ── Main grid ── */}
      <div style={{ display: "grid", gridTemplateColumns: "1fr 300px", gap: 20, marginBottom: 20 }}>

        {/* Preview card */}
        <div style={{ background: c.bg, border: `1px solid ${c.border}`, borderRadius: 12, overflow: "hidden", boxShadow: c.shadow }}>
          <div
            onClick={() => previewInputRef.current?.click()}
            style={{ position: "relative", background: "#f8f8f8", minHeight: 340, display: "flex", alignItems: "center", justifyContent: "center", cursor: "pointer", overflow: "hidden" }}
          >
            {previewUrl ? (
              <>
                <img src={previewUrl} alt="Creative" style={{ width: "100%", height: "100%", objectFit: "contain", display: "block", maxHeight: 400 }} />
                <div
                  style={{ position: "absolute", inset: 0, background: "rgba(0,0,0,0)", display: "flex", alignItems: "center", justifyContent: "center", transition: "background 0.15s" }}
                  onMouseEnter={e => (e.currentTarget.style.background = "rgba(0,0,0,0.28)")}
                  onMouseLeave={e => (e.currentTarget.style.background = "rgba(0,0,0,0)")}
                >
                  <span style={{ color: "#fff", fontSize: 12, fontWeight: 600, background: "rgba(0,0,0,0.55)", padding: "5px 14px", borderRadius: 6, opacity: 0, transition: "opacity 0.15s", pointerEvents: "none" }}
                    ref={el => { if (el) { el.parentElement!.addEventListener("mouseenter", () => { el.style.opacity = "1"; }); el.parentElement!.addEventListener("mouseleave", () => { el.style.opacity = "0"; }); } }}>
                    Replace image
                  </span>
                </div>
              </>
            ) : (
              <div style={{ textAlign: "center", padding: 40 }}>
                <svg width="52" height="52" viewBox="0 0 52 52" fill="none" style={{ display: "block", margin: "0 auto 14px" }}>
                  <rect x="4" y="10" width="44" height="32" rx="4" fill={c.amberLight} stroke={c.amber} strokeWidth="1.8"/>
                  <circle cx="14" cy="20" r="4" fill={c.amber}/>
                  <path d="M4 34l13-11 9 9 7-6 15 11" stroke={c.green} strokeWidth="2" strokeLinejoin="round" fill="none"/>
                </svg>
                <div style={{ fontSize: 14, fontWeight: 600, color: c.text, marginBottom: 4 }}>Creative Preview</div>
                <div style={{ fontSize: 12, color: c.textTer }}>Click to upload your creative image</div>
              </div>
            )}
          </div>

          {/* Annotation bar */}
          <div style={{ padding: "13px 18px", borderTop: `1px solid ${c.border}`, display: "flex", gap: 8, flexWrap: "wrap", alignItems: "center" }}>
            <Badge variant="green">✓ Product visible</Badge>
            <Badge variant="green">✓ Brand match</Badge>
            <Badge variant="amber">⚠ 3 issues</Badge>
            <div style={{ marginLeft: "auto" }}>
              <Btn variant="ghost" small onClick={() => previewInputRef.current?.click()}>
                {previewUrl ? "Replace" : "Upload creative"}
              </Btn>
            </div>
          </div>
        </div>

        {/* Score panel */}
        <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
          {/* Score card */}
          <div style={{ background: c.bg, border: `1px solid ${c.border}`, borderRadius: 12, padding: 20, boxShadow: c.shadow }}>
            <div style={{ fontSize: 10, fontWeight: 700, color: c.textTer, textTransform: "uppercase", letterSpacing: "0.08em", marginBottom: 10 }}>Creative Ready Score</div>
            <div style={{ display: "flex", alignItems: "flex-end", gap: 6, marginBottom: 14 }}>
              <span style={{ fontSize: 64, fontWeight: 800, fontFamily: "var(--font-mono)", lineHeight: 1, color: scoreColor }}>{score}</span>
              <span style={{ fontSize: 18, color: c.textTer, fontFamily: "var(--font-mono)", paddingBottom: 8 }}>/100</span>
            </div>
            {/* Verdict banner */}
            <div style={{ background: c.redLight, border: `1px solid #fca5a5`, borderRadius: 8, padding: "10px 14px", marginBottom: 16, display: "flex", alignItems: "center", gap: 8 }}>
              <span style={{ width: 8, height: 8, borderRadius: "50%", background: c.red, flexShrink: 0, display: "inline-block" }} />
              <span style={{ fontSize: 12, fontWeight: 600, color: c.redDark, lineHeight: 1.3 }}>Fix 3 issues before publishing</span>
            </div>
            <div style={{ display: "flex", gap: 8 }}>
              <Btn fullWidth onClick={() => onNav("fix-preview")}>Fix Issues</Btn>
              <Btn variant="secondary" onClick={() => onNav("issues")}>Details</Btn>
            </div>
          </div>

          {/* Breakdown card */}
          <div style={{ background: c.bg, border: `1px solid ${c.border}`, borderRadius: 12, padding: 18, boxShadow: c.shadow }}>
            <div style={{ fontSize: 10, fontWeight: 700, color: c.textTer, textTransform: "uppercase", letterSpacing: "0.08em", marginBottom: 14 }}>Score Breakdown</div>
            {breakdown.map(b => {
              const col = b.score >= 85 ? c.green : b.score >= 70 ? c.amber : c.red;
              return (
                <div key={b.label} style={{ marginBottom: 11 }}>
                  <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 5 }}>
                    <span style={{ fontSize: 12, color: c.textSec }}>{b.label} <span style={{ fontSize: 10, color: c.textTer }}>({b.weight})</span></span>
                    <span style={{ fontFamily: "var(--font-mono)", fontSize: 12, fontWeight: 700, color: col }}>{b.score}</span>
                  </div>
                  <div style={{ height: 5, background: c.bgTer, borderRadius: 3 }}>
                    <div style={{ width: `${b.score}%`, height: "100%", borderRadius: 3, background: col }} />
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* ── Issues list ── */}
      <div style={{ background: c.bg, border: `1px solid ${c.border}`, borderRadius: 12, overflow: "hidden", boxShadow: c.shadow }}>
        <div style={{ padding: "14px 20px", borderBottom: `1px solid ${c.border}`, display: "flex", justifyContent: "space-between", alignItems: "center" }}>
          <div style={{ fontWeight: 600, fontSize: 14, color: c.text }}>Issues Found <span style={{ fontWeight: 400, color: c.textTer }}>({issues.length})</span></div>
          <button onClick={() => onNav("issues")} style={{ background: "transparent", border: "none", fontSize: 12, color: c.textSec, cursor: "pointer", fontFamily: "var(--font-sans)" }}>View full report →</button>
        </div>
        {issues.map((issue, i) => (
          <div key={issue.title} style={{ padding: "14px 20px", borderBottom: i < issues.length - 1 ? `1px solid ${c.border}` : "none", display: "flex", alignItems: "center", gap: 14 }}
            onMouseEnter={e => (e.currentTarget.style.background = c.bgAlt)}
            onMouseLeave={e => (e.currentTarget.style.background = "transparent")}
          >
            <div style={{ width: 9, height: 9, borderRadius: "50%", background: issue.sev === "red" ? c.red : c.amber, flexShrink: 0 }} />
            <div style={{ flex: 1 }}>
              <div style={{ fontSize: 10, fontWeight: 700, color: c.textTer, letterSpacing: "0.06em", textTransform: "uppercase", marginBottom: 3 }}>{issue.category}</div>
              <div style={{ fontSize: 13, color: c.text }}>{issue.title}</div>
            </div>
            <Badge variant={issue.sev === "red" ? "red" : "amber"}>{issue.sev === "red" ? "Critical" : "Warning"}</Badge>
            {issue.fixable && <Btn variant="ghost" small onClick={() => onNav("fix-preview")}>Fix</Btn>}
          </div>
        ))}
      </div>
    </div>
  );
}

// ─── Screen 5: Issues Detail ──────────────────────────────────────────────────
function IssuesDetail({ onNav }: { onNav: (s: Screen) => void }) {
  const [expanded, setExpanded] = useState<number[]>([0]);
  const [dismissed, setDismissed] = useState<number[]>([]);
  const allIssues = [
    { sev: "red" as const, category: "PRODUCT", title: "Logo differs from approved reference", confidence: 94, fixable: true, why: "Inconsistent logos reduce brand recognition and signal inauthenticity to audiences." },
    { sev: "amber" as const, category: "DESIGN", title: "CTA becomes difficult to read at mobile size", confidence: 87, fixable: false, why: "At 390px width, the button text falls below 12px effective size." },
    { sev: "amber" as const, category: "AI QUALITY", title: "Charm connection appears physically impossible", confidence: 87, fixable: true, why: "The charm appears to float without a realistic attachment point." },
  ];
  const issues = allIssues.filter((_, i) => !dismissed.includes(i));

  return (
    <div style={{ padding: 28, maxWidth: 840 }}>
      <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 20 }}>
        <button onClick={() => onNav("results")} style={{ background: "transparent", border: `1px solid ${c.border}`, borderRadius: 6, padding: "5px 12px", cursor: "pointer", fontFamily: "var(--font-sans)", fontSize: 12, color: c.textSec }}>← Results</button>
        <div>
          <div style={{ fontWeight: 700, fontSize: 18, color: c.text }}>Issues Found</div>
          <div style={{ fontSize: 12, color: c.textSec }}>{issues.length} of {allIssues.length} · Travel Campaign{dismissed.length > 0 ? ` · ${dismissed.length} dismissed` : ""}</div>
        </div>
      </div>
      {issues.length === 0 && (
        <Card style={{ textAlign: "center", padding: 32, color: c.textSec }}>All issues dismissed. <button onClick={() => setDismissed([])} style={{ background: "none", border: "none", color: c.blue, cursor: "pointer", fontFamily: "var(--font-sans)", fontSize: 13 }}>Undo</button></Card>
      )}
      <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
        {issues.map((issue, i) => {
          const globalIdx = allIssues.indexOf(issue);
          const open = expanded.includes(i);
          return (
            <Card key={issue.title} style={{ padding: 16 }}>
              <div style={{ display: "flex", alignItems: "flex-start", gap: 12, cursor: "pointer" }} onClick={() => setExpanded(e => open ? e.filter(x => x !== i) : [...e, i])}>
                <span style={{ fontSize: 18, marginTop: 1 }}>{issue.sev === "red" ? "🔴" : "🟠"}</span>
                <div style={{ flex: 1 }}>
                  <div style={{ display: "flex", gap: 6, marginBottom: 5 }}>
                    <Badge variant={issue.sev === "red" ? "red" : "amber"}>{issue.category}</Badge>
                    <Badge variant={issue.fixable ? "green" : "gray"}>{issue.fixable ? "Auto-fixable" : "Manual only"}</Badge>
                  </div>
                  <div style={{ fontWeight: 600, fontSize: 14, color: c.text }}>{issue.title}</div>
                  <div style={{ fontSize: 11, color: c.textSec, marginTop: 3 }}>Confidence: <span style={{ fontFamily: "var(--font-mono)", fontWeight: 600, color: c.text }}>{issue.confidence}%</span></div>
                </div>
                <span style={{ color: c.textTer, fontSize: 12 }}>{open ? "▲" : "▼"}</span>
              </div>
              {open && (
                <>
                  <Divider />
                  <div style={{ fontSize: 13, color: c.textSec, marginBottom: 12 }}>
                    <strong style={{ color: c.text }}>Why it matters: </strong>{issue.why}
                  </div>
                  <div style={{ display: "flex", gap: 8 }}>
                    {issue.fixable ? <Btn small onClick={() => onNav("fix-preview")}>Fix This</Btn> : <Btn variant="ghost" small onClick={() => { setDismissed(d => [...d, globalIdx]); setExpanded(e => e.filter(x => x !== i)); }}>Dismiss</Btn>}
                  </div>
                </>
              )}
            </Card>
          );
        })}
      </div>
      <div style={{ marginTop: 18, display: "flex", gap: 8 }}>
        <Btn onClick={() => onNav("fix-preview")}>Fix All Fixable</Btn>
        <Btn variant="ghost" onClick={() => onNav("results")}>← Results</Btn>
      </div>
    </div>
  );
}

// ─── Screen 6: Fix Preview ────────────────────────────────────────────────────
function FixPreview({ onNav }: { onNav: (s: Screen) => void }) {
  const [selected, setSelected] = useState([0, 1]);
  const fixes = [
    { cat: "Product",    title: "Logo color correction",         quality: 92, time: "15s" },
    { cat: "AI Quality", title: "Blur charm connection artifact", quality: 88, time: "10s" },
  ];
  return (
    <div style={{ padding: 28, maxWidth: 680 }}>
      <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 20 }}>
        <button onClick={() => onNav("issues")} style={{ background: "transparent", border: `1px solid ${c.border}`, borderRadius: 6, padding: "5px 12px", cursor: "pointer", fontFamily: "var(--font-sans)", fontSize: 12, color: c.textSec }}>← Issues</button>
        <div>
          <div style={{ fontWeight: 700, fontSize: 18, color: c.text }}>Fix Preview</div>
          <div style={{ fontSize: 12, color: c.textSec }}>Estimated new score: <strong>91/100 (+7 pts)</strong></div>
        </div>
      </div>
      <Card style={{ marginBottom: 14 }}>
        <div style={{ fontWeight: 600, fontSize: 13, color: c.text, marginBottom: 14 }}>Auto-fixable ({fixes.length})</div>
        {fixes.map((f, i) => (
          <div key={f.title} style={{ display: "flex", gap: 12, alignItems: "flex-start", padding: "12px 0", borderBottom: i < fixes.length - 1 ? `1px solid ${c.border}` : "none" }}>
            <input type="checkbox" checked={selected.includes(i)} onChange={() => setSelected(s => s.includes(i) ? s.filter(x => x !== i) : [...s, i])} style={{ marginTop: 3, accentColor: "#111827", width: 14, height: 14, cursor: "pointer" }} />
            <div>
              <Badge variant="green">{f.cat}</Badge>
              <div style={{ fontWeight: 500, marginTop: 6, marginBottom: 2, color: c.text, fontSize: 13 }}>{f.title}</div>
              <div style={{ fontSize: 11, color: c.textSec }}>Quality: <span style={{ fontFamily: "var(--font-mono)", fontWeight: 600, color: c.text }}>{f.quality}/100</span> · {f.time}</div>
            </div>
          </div>
        ))}
        <div style={{ marginTop: 14 }}>
          <Btn disabled={selected.length === 0} onClick={() => onNav("fix-processing")}>Apply {selected.length} Fix{selected.length !== 1 ? "es" : ""}</Btn>
        </div>
      </Card>
      <Card style={{ marginBottom: 18 }}>
        <div style={{ fontWeight: 600, fontSize: 13, color: c.text, marginBottom: 8 }}>Manual only (1)</div>
        <div style={{ fontSize: 13, color: c.textSec }}>CTA readability at mobile — requires redesign</div>
      </Card>
      <div style={{ display: "flex", gap: 8 }}>
        <Btn variant="ghost" onClick={() => onNav("issues")}>Cancel</Btn>
        <Btn disabled={selected.length === 0} onClick={() => onNav("fix-processing")}>Auto-Fix All</Btn>
      </div>
    </div>
  );
}

// ─── Screen 7: Fix Processing ─────────────────────────────────────────────────
function FixProcessing({ onNav }: { onNav: (s: Screen) => void }) {
  const [progress, setProgress] = useState(0);
  const [doneIdx, setDoneIdx] = useState(-1);

  useEffect(() => {
    const interval = setInterval(() => {
      setProgress(p => {
        if (p >= 100) { clearInterval(interval); return 100; }
        return p + 2;
      });
    }, 60);
    const t1 = setTimeout(() => setDoneIdx(0), 1800);
    const t2 = setTimeout(() => setDoneIdx(1), 3600);
    return () => { clearInterval(interval); clearTimeout(t1); clearTimeout(t2); };
  }, []);

  const fixes = [
    { label: "Product Logo Color Correction", confidence: 94 },
    { label: "Charm Connection Blur",         confidence: 87 },
  ];

  return (
    <div style={{ padding: 28, maxWidth: 580 }}>
      <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 16 }}>
        <button onClick={() => onNav("fix-preview")} style={{ background: "transparent", border: `1px solid ${c.border}`, borderRadius: 6, padding: "5px 12px", cursor: "pointer", fontFamily: "var(--font-sans)", fontSize: 12, color: c.textSec }}>← Back</button>
        <div style={{ fontWeight: 700, fontSize: 18, color: c.text }}>Applying fixes…</div>
      </div>
      <div style={{ fontSize: 13, color: c.textSec, marginBottom: 20 }}>Processing {fixes.length} of {fixes.length} fixes</div>
      <Card style={{ marginBottom: 16 }}>
        <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 8, fontSize: 13 }}>
          <span style={{ color: c.textSec }}>Overall progress</span>
          <span style={{ fontFamily: "var(--font-mono)", fontWeight: 700, color: c.text }}>{progress}%</span>
        </div>
        <div style={{ height: 6, background: c.bgTer, borderRadius: 4, overflow: "hidden" }}>
          <div style={{ width: `${progress}%`, height: "100%", background: progress === 100 ? c.green : "#111827", borderRadius: 4, transition: "width 0.06s linear, background 0.3s" }} />
        </div>
      </Card>
      <div style={{ display: "flex", flexDirection: "column", gap: 10, marginBottom: 24 }}>
        {fixes.map((fix, i) => {
          const done = doneIdx >= i;
          return (
            <Card key={fix.label} style={{ padding: 14 }}>
              <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                <span style={{ fontSize: 18 }}>{done ? "✓" : "⏳"}</span>
                <div style={{ flex: 1 }}>
                  <div style={{ fontWeight: 500, fontSize: 13, color: c.text }}>{fix.label}</div>
                  <div style={{ fontSize: 11, color: c.textSec }}>Confidence: <span style={{ fontFamily: "var(--font-mono)", fontWeight: 600 }}>{fix.confidence}%</span></div>
                </div>
                <Badge variant={done ? "green" : "gray"}>{done ? "Done" : "Processing"}</Badge>
              </div>
            </Card>
          );
        })}
      </div>
      <Btn onClick={() => onNav("fix-results")}>
        {progress === 100 ? "View Results →" : "Skip to Results →"}
      </Btn>
    </div>
  );
}

// ─── Screen 8: Fix Results ────────────────────────────────────────────────────
function FixResults({ onNav }: { onNav: (s: Screen) => void }) {
  const dlRef = useRef<HTMLAnchorElement>(null);
  function handleDownloadFixed() {
    const report = `VERITY Fix Report — Travel Campaign\n\nScore: 84 → 91 (+7 pts)\nStatus: Ready to publish\n\nApplied Fixes:\n1. Product Logo Color Corrected (Gradient correction applied)\n2. Charm Connection Artifact Blurred (Gaussian blur + edge refinement)\n\nRemaining: 1 manual issue (CTA readability at mobile size)\n\nGenerated by VERITY Creative QA Platform`;
    const blob = new Blob([report], { type: "text/plain" });
    const url = URL.createObjectURL(blob);
    if (dlRef.current) { dlRef.current.href = url; dlRef.current.download = "verity-fix-report.txt"; dlRef.current.click(); }
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  }
  return (
    <div style={{ padding: 28, maxWidth: 860 }}>
      <div style={{ display: "flex", alignItems: "center", gap: 14, marginBottom: 20 }}>
        <button onClick={() => onNav("results")} style={{ background: "transparent", border: `1px solid ${c.border}`, borderRadius: 6, padding: "5px 12px", cursor: "pointer", fontFamily: "var(--font-sans)", fontSize: 12, color: c.textSec }}>← Results</button>
        <div>
          <div style={{ fontWeight: 700, fontSize: 18, color: c.text }}>Fixes applied</div>
          <div style={{ display: "flex", alignItems: "center", gap: 10, marginTop: 3 }}>
            <span style={{ fontSize: 22, fontFamily: "var(--font-mono)", fontWeight: 700, color: c.green }}>91/100</span>
            <Badge variant="green">✓ Ready to publish</Badge>
            <span style={{ fontSize: 12, color: c.green, fontWeight: 500 }}>+7 pts</span>
          </div>
        </div>
      </div>
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16, marginBottom: 16 }}>
        {[
          { label: "BEFORE", sub: "Original creative", score: "84/100", issues: "3 issues", scoreColor: c.amber, variant: "amber" as const },
          { label: "AFTER",  sub: "Fixed creative",    score: "91/100", issues: "1 remaining", scoreColor: c.green, variant: "green" as const },
        ].map(side => (
          <Card key={side.label}>
            <div style={{ fontSize: 10, fontWeight: 700, color: c.textTer, letterSpacing: "0.05em", marginBottom: 10, textTransform: "uppercase" }}>{side.label} · {side.sub}</div>
            <div style={{ background: c.bgAlt, borderRadius: 8, aspectRatio: "4/3", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 13, color: c.textTer, marginBottom: 12, border: `1px solid ${c.border}` }}>{side.sub}</div>
            <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
              <span style={{ fontFamily: "var(--font-mono)", fontWeight: 700, color: side.scoreColor, fontSize: 14 }}>{side.score}</span>
              <Badge variant={side.variant}>{side.issues}</Badge>
            </div>
          </Card>
        ))}
      </div>
      <Card style={{ marginBottom: 14, padding: 0, overflow: "hidden" }}>
        <div style={{ padding: "12px 18px", borderBottom: `1px solid ${c.border}`, fontWeight: 600, fontSize: 13, color: c.text }}>Applied Fixes</div>
        {[
          { title: "Product Logo Color Corrected",        note: "Gradient correction applied" },
          { title: "Charm Connection Artifact Blurred",   note: "Gaussian blur + edge refinement" },
        ].map((fix, i, arr) => (
          <div key={fix.title} style={{ padding: "12px 18px", borderBottom: i < arr.length - 1 ? `1px solid ${c.border}` : "none", display: "flex", gap: 10, alignItems: "center" }}>
            <span style={{ color: c.green, fontSize: 16 }}>✓</span>
            <div style={{ flex: 1 }}>
              <div style={{ fontWeight: 500, fontSize: 13, color: c.text }}>{fix.title}</div>
              <div style={{ fontSize: 11, color: c.textSec }}>{fix.note}</div>
            </div>
          </div>
        ))}
      </Card>
      <div style={{ display: "flex", gap: 8 }}>
        <a ref={dlRef} style={{ display: "none" }} />
        <Btn onClick={() => onNav("dashboard")}>Done →</Btn>
        <Btn variant="secondary" onClick={handleDownloadFixed}>⬇ Download Report</Btn>
        <Btn variant="ghost" onClick={() => onNav("new-check")}>New Check</Btn>
      </div>
    </div>
  );
}

// ─── Screen 9: Brand Kit ──────────────────────────────────────────────────────
function BrandKit({ onNav }: { onNav: (s: Screen) => void }) {
  const [tab, setTab] = useState("overview");
  const [brandName, setBrandName] = useState("Nomad Studio");
  const [colors, setColors] = useState([{ name: "Gold", hex: "#D4AF37" }, { name: "Navy", hex: "#1A1F36" }, { name: "Cream", hex: "#F5F1ED" }]);
  const [activeStyles, setActiveStyles] = useState(["Editorial", "Premium", "Travel"]);
  const [logoUrl, setLogoUrl] = useState<string | null>(null);
  const logoInputRef = useRef<HTMLInputElement>(null);
  const { saved, save } = useSave();

  function handleLogoUpload(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (file) {
      const url = URL.createObjectURL(file);
      setLogoUrl(url);
    }
    e.target.value = "";
  }

  return (
    <div style={{ padding: 28, maxWidth: 760 }}>
      {saved && <Toast msg="Brand kit saved" />}
      <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 22 }}>
        <button onClick={() => onNav("dashboard")} style={{ background: "transparent", border: `1px solid ${c.border}`, borderRadius: 6, padding: "5px 12px", cursor: "pointer", fontFamily: "var(--font-sans)", fontSize: 12, color: c.textSec }}>← Dashboard</button>
        <div style={{ fontWeight: 700, fontSize: 18, color: c.text }}>Brand Kit</div>
      </div>

      <div style={{ display: "flex", borderBottom: `1px solid ${c.border}`, marginBottom: 22 }}>
        {["Overview", "Rules", "Visual Style"].map(t => {
          const id = t.toLowerCase().replace(" ", "-");
          const active = tab === id;
          return <button key={t} onClick={() => setTab(id)} style={{ padding: "8px 16px", border: "none", background: "transparent", cursor: "pointer", fontFamily: "var(--font-sans)", fontSize: 13, fontWeight: active ? 600 : 400, color: active ? c.text : c.textSec, borderBottom: `2px solid ${active ? "#111827" : "transparent"}`, marginBottom: -1 }}>{t}</button>;
        })}
      </div>

      {tab === "overview" && (
        <div style={{ maxWidth: 480, display: "flex", flexDirection: "column", gap: 14 }}>
          <Card>
            <div style={{ fontWeight: 600, fontSize: 13, color: c.text, marginBottom: 14 }}>Brand Identity</div>
            <label style={{ fontSize: 12, fontWeight: 500, color: c.textSec, display: "block", marginBottom: 6 }}>Brand Name</label>
            <input value={brandName} onChange={e => setBrandName(e.target.value)} style={{ width: "100%", padding: "8px 12px", border: `1px solid ${c.border}`, borderRadius: 7, fontFamily: "var(--font-sans)", fontSize: 13, outline: "none", boxSizing: "border-box", marginBottom: 14 }} />
            <label style={{ fontSize: 12, fontWeight: 500, color: c.textSec, display: "block", marginBottom: 6 }}>Logo</label>
            <input ref={logoInputRef} type="file" accept="image/*" style={{ display: "none" }} onChange={handleLogoUpload} />
            <div style={{ display: "flex", alignItems: "center", gap: 12, padding: 14, border: `1px solid ${c.border}`, borderRadius: 8, background: c.bgAlt }}>
              {logoUrl ? (
                <img src={logoUrl} alt="logo" style={{ width: 44, height: 44, borderRadius: 8, objectFit: "cover", border: `1px solid ${c.border}` }} />
              ) : (
                <div style={{ width: 44, height: 44, background: "#111827", borderRadius: 8, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 17, fontWeight: 800, color: "#fff" }}>{brandName[0] || "?"}</div>
              )}
              <div style={{ display: "flex", gap: 8 }}>
                <Btn variant="secondary" small onClick={() => logoInputRef.current?.click()}>Upload Logo</Btn>
                {logoUrl && <Btn variant="ghost" small onClick={() => setLogoUrl(null)}>Remove</Btn>}
              </div>
            </div>
          </Card>
          <div style={{ display: "flex", gap: 8 }}>
            <Btn onClick={save}>Save</Btn>
            <Btn variant="ghost" onClick={() => onNav("dashboard")}>Cancel</Btn>
          </div>
        </div>
      )}

      {tab === "rules" && (
        <div style={{ maxWidth: 480, display: "flex", flexDirection: "column", gap: 14 }}>
          <Card>
            <div style={{ fontWeight: 600, fontSize: 13, color: c.text, marginBottom: 14 }}>Color Palette</div>
            {colors.map((col, i) => (
              <div key={i} style={{ display: "flex", alignItems: "center", gap: 10, padding: "9px 0", borderBottom: `1px solid ${c.border}` }}>
                <div style={{ width: 26, height: 26, borderRadius: 6, background: col.hex, border: `1px solid ${c.border}`, flexShrink: 0 }} />
                <input value={col.name} onChange={e => setColors(cs => cs.map((x, j) => j === i ? { ...x, name: e.target.value } : x))} style={{ flex: 1, border: "none", background: "transparent", fontFamily: "var(--font-sans)", fontSize: 13, fontWeight: 500, outline: "none" }} />
                <input value={col.hex} onChange={e => setColors(cs => cs.map((x, j) => j === i ? { ...x, hex: e.target.value } : x))} style={{ width: 80, fontFamily: "var(--font-mono)", fontSize: 12, color: c.textSec, border: `1px solid ${c.border}`, borderRadius: 4, padding: "3px 6px", outline: "none" }} />
                <button onClick={() => setColors(cs => cs.filter((_, j) => j !== i))} style={{ background: "transparent", border: "none", cursor: "pointer", color: c.textTer, fontSize: 18, lineHeight: 1 }}>×</button>
              </div>
            ))}
            <div style={{ marginTop: 10 }}>
              <Btn variant="ghost" small onClick={() => setColors(cs => [...cs, { name: "New Color", hex: "#000000" }])}>+ Add color</Btn>
            </div>
          </Card>
          <div style={{ display: "flex", gap: 8 }}><Btn onClick={save}>Save</Btn></div>
        </div>
      )}

      {tab === "visual-style" && (
        <div style={{ maxWidth: 480 }}>
          <Card style={{ marginBottom: 14 }}>
            <div style={{ fontWeight: 600, fontSize: 13, color: c.text, marginBottom: 12 }}>Brand Style Tags</div>
            <div style={{ display: "flex", flexWrap: "wrap", gap: 7 }}>
              {["Editorial", "Premium", "Minimal", "Travel", "Bold", "Playful", "Warm tone", "Dark", "Luxury", "Clean"].map(s => {
                const on = activeStyles.includes(s);
                return <button key={s} onClick={() => setActiveStyles(a => on ? a.filter(x => x !== s) : [...a, s])} style={{ padding: "5px 12px", borderRadius: 5, border: `1px solid ${on ? "#111827" : c.border}`, background: on ? "#111827" : c.bg, color: on ? "#fff" : c.textSec, fontFamily: "var(--font-sans)", fontSize: 12, cursor: "pointer", fontWeight: on ? 500 : 400 }}>{s}</button>;
              })}
            </div>
          </Card>
          <div style={{ display: "flex", gap: 8 }}>
            <Btn onClick={save}>Save</Btn>
            <Btn variant="ghost" onClick={() => setActiveStyles([])}>Clear All</Btn>
          </div>
        </div>
      )}
    </div>
  );
}

// ─── Screen 10: Product Library ───────────────────────────────────────────────
type Product = { id: number; name: string; imageUrls: string[]; dna: { label: string; value: string }[] };

function ProductLibrary({ onNav }: { onNav: (s: Screen) => void }) {
  const [products, setProducts] = useState<Product[]>([
    { id: 1, name: "Keychain Pendant", imageUrls: [], dna: [{ label: "Shape", value: "Rectangular pendant" }, { label: "Materials", value: "Resin + gold metal" }, { label: "Colors", value: "Gold, navy, cream" }, { label: "Dimensions", value: "~2cm × 3cm" }] },
    { id: 2, name: "Gold Charm",       imageUrls: [], dna: [{ label: "Shape", value: "Circular disc" }, { label: "Materials", value: "14k gold plated" }, { label: "Colors", value: "Gold, champagne" }] },
  ]);
  const [editing, setEditing] = useState<number | null>(null);
  const [editName, setEditName] = useState("");
  const [viewImages, setViewImages] = useState<number | null>(null);
  const uploadInputRef = useRef<HTMLInputElement>(null);
  const { saved, save } = useSave();

  function deleteProduct(id: number) { setProducts(ps => ps.filter(p => p.id !== id)); }
  function startEdit(p: Product) { setEditing(p.id); setEditName(p.name); }
  function confirmEdit() { setProducts(ps => ps.map(p => p.id === editing ? { ...p, name: editName } : p)); setEditing(null); save(); }
  function addProduct() {
    const id = Math.max(0, ...products.map(p => p.id)) + 1;
    const np: Product = { id, name: `New Product ${id}`, imageUrls: [], dna: [] };
    setProducts(ps => [...ps, np]);
    setEditing(id); setEditName(np.name);
  }
  function handleImageUpload(e: React.ChangeEvent<HTMLInputElement>) {
    if (!e.target.files || viewImages === null) return;
    const urls = Array.from(e.target.files).map(f => URL.createObjectURL(f));
    setProducts(ps => ps.map(p => p.id === viewImages ? { ...p, imageUrls: [...p.imageUrls, ...urls] } : p));
    e.target.value = "";
  }
  function removeImage(productId: number, idx: number) {
    setProducts(ps => ps.map(p => p.id === productId ? { ...p, imageUrls: p.imageUrls.filter((_, i) => i !== idx) } : p));
  }

  const viewProduct = viewImages !== null ? products.find(p => p.id === viewImages) : null;

  return (
    <div style={{ padding: 28, maxWidth: 860 }}>
      {saved && <Toast msg="Product saved" />}
      <input ref={uploadInputRef} type="file" accept="image/*" multiple style={{ display: "none" }} onChange={handleImageUpload} />

      {viewProduct && (
        <div style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,0.45)", zIndex: 100, display: "flex", alignItems: "center", justifyContent: "center" }} onClick={() => setViewImages(null)}>
          <div className="anim-fade" style={{ background: c.bg, borderRadius: 14, padding: 28, maxWidth: 500, width: "92%", maxHeight: "80vh", display: "flex", flexDirection: "column", boxShadow: c.shadowMd }} onClick={e => e.stopPropagation()}>
            {/* Modal header */}
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 6, flexShrink: 0 }}>
              <div style={{ fontWeight: 700, fontSize: 16, color: c.text }}>{viewProduct.name}</div>
              <button onClick={() => setViewImages(null)} style={{ background: "transparent", border: "none", cursor: "pointer", fontSize: 22, color: c.textTer, lineHeight: 1, padding: "2px 4px" }}>×</button>
            </div>
            <div style={{ fontSize: 12, color: c.textSec, marginBottom: 16, flexShrink: 0 }}>
              {viewProduct.imageUrls.length} reference image{viewProduct.imageUrls.length !== 1 ? "s" : ""}
            </div>

            {/* Image grid */}
            <div style={{ overflowY: "auto", flex: 1, marginBottom: 16 }}>
              {viewProduct.imageUrls.length === 0 ? (
                /* Empty state — big clickable drop area */
                <div
                  onClick={() => uploadInputRef.current?.click()}
                  style={{ border: `1.5px dashed ${c.borderDark}`, borderRadius: 10, padding: "48px 20px", textAlign: "center", cursor: "pointer", background: c.bgAlt, color: c.textSec }}
                >
                  <div style={{ fontSize: 28, marginBottom: 10 }}>
                    <svg width="28" height="32" viewBox="0 0 24 28" fill="none" style={{ display: "inline-block" }}>
                      <rect x="3" y="1" width="14" height="19" rx="2" stroke={c.textTer} strokeWidth="1.5" fill={c.bgAlt}/>
                      <path d="M13 1v5h7" stroke={c.textTer} strokeWidth="1.5" strokeLinejoin="round"/>
                      <circle cx="16" cy="19" r="6" fill={c.bgAlt} stroke={c.borderDark} strokeWidth="1.2"/>
                      <path d="M16 16v6M13 19h6" stroke={c.textSec} strokeWidth="1.4" strokeLinecap="round"/>
                    </svg>
                  </div>
                  <div style={{ fontWeight: 600, fontSize: 14, marginBottom: 4, color: c.text }}>Add reference images</div>
                  <div style={{ fontSize: 12 }}>Click to browse or drag images here</div>
                </div>
              ) : (
                <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 8 }}>
                  {viewProduct.imageUrls.map((url, i) => (
                    <div key={i} style={{ position: "relative", aspectRatio: "1", borderRadius: 8, overflow: "hidden", border: `1px solid ${c.border}` }}
                      onMouseEnter={e => { const btn = e.currentTarget.querySelector(".del-btn") as HTMLElement; if (btn) btn.style.opacity = "1"; }}
                      onMouseLeave={e => { const btn = e.currentTarget.querySelector(".del-btn") as HTMLElement; if (btn) btn.style.opacity = "0"; }}
                    >
                      <img src={url} alt={`ref ${i + 1}`} style={{ width: "100%", height: "100%", objectFit: "cover", display: "block" }} />
                      <button className="del-btn" onClick={() => removeImage(viewProduct.id, i)} style={{ position: "absolute", top: 4, right: 4, background: "rgba(0,0,0,0.55)", border: "none", borderRadius: 4, color: "#fff", fontSize: 13, lineHeight: 1, padding: "3px 6px", cursor: "pointer", opacity: 0, transition: "opacity 0.15s" }}>×</button>
                    </div>
                  ))}
                  {/* Add more slot */}
                  <div onClick={() => uploadInputRef.current?.click()} style={{ aspectRatio: "1", borderRadius: 8, border: `1.5px dashed ${c.borderDark}`, background: c.bgAlt, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", cursor: "pointer", gap: 4 }}>
                    <span style={{ fontSize: 20, color: c.textTer, lineHeight: 1 }}>+</span>
                    <span style={{ fontSize: 10, color: c.textTer }}>Add</span>
                  </div>
                </div>
              )}
            </div>

            {/* Modal footer */}
            <div style={{ display: "flex", gap: 8, flexShrink: 0 }}>
              <Btn small onClick={() => uploadInputRef.current?.click()}>
                + Upload Images
              </Btn>
              <Btn variant="ghost" small onClick={() => setViewImages(null)}>Close</Btn>
            </div>
          </div>
        </div>
      )}

      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 22 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
          <button onClick={() => onNav("dashboard")} style={{ background: "transparent", border: `1px solid ${c.border}`, borderRadius: 6, padding: "5px 12px", cursor: "pointer", fontFamily: "var(--font-sans)", fontSize: 12, color: c.textSec }}>← Dashboard</button>
          <div>
            <div style={{ fontWeight: 700, fontSize: 18, color: c.text }}>Product Library</div>
            <div style={{ fontSize: 12, color: c.textSec }}>{products.length} products</div>
          </div>
        </div>
        <Btn small onClick={addProduct}>+ Add Product</Btn>
      </div>

      <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
        {products.map(product => (
          <Card key={product.id} style={{ padding: 18 }}>
            {editing === product.id ? (
              <div style={{ display: "flex", gap: 8, alignItems: "center", marginBottom: 14 }}>
                <input value={editName} onChange={e => setEditName(e.target.value)} autoFocus onKeyDown={e => e.key === "Enter" && confirmEdit()} style={{ flex: 1, padding: "7px 12px", border: `2px solid #111827`, borderRadius: 7, fontFamily: "var(--font-sans)", fontSize: 15, fontWeight: 600, outline: "none" }} />
                <Btn small onClick={confirmEdit}>Save</Btn>
                <Btn variant="ghost" small onClick={() => setEditing(null)}>Cancel</Btn>
              </div>
            ) : (
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: product.dna.length > 0 ? 14 : 0 }}>
                <div>
                  <div style={{ fontWeight: 700, fontSize: 15, color: c.text, marginBottom: 2 }}>{product.name}</div>
                  <div style={{ fontSize: 12, color: c.textSec }}>{product.imageUrls.length} reference image{product.imageUrls.length !== 1 ? "s" : ""}</div>
                </div>
                <div style={{ display: "flex", gap: 7 }}>
                  <Btn variant="secondary" small onClick={() => setViewImages(product.id)}>Images</Btn>
                  <Btn variant="secondary" small onClick={() => startEdit(product)}>Edit</Btn>
                  <Btn variant="danger" small onClick={() => deleteProduct(product.id)}>Delete</Btn>
                </div>
              </div>
            )}
            {product.imageUrls.length > 0 && editing !== product.id && (
              <div style={{ display: "flex", gap: 6, marginBottom: product.dna.length > 0 ? 14 : 0, flexWrap: "wrap" }}>
                {product.imageUrls.slice(0, 5).map((url, i) => (
                  <img key={i} src={url} alt="" style={{ width: 40, height: 40, borderRadius: 6, objectFit: "cover", border: `1px solid ${c.border}` }} />
                ))}
                {product.imageUrls.length > 5 && <div style={{ width: 40, height: 40, borderRadius: 6, background: c.bgTer, border: `1px solid ${c.border}`, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 11, color: c.textSec }}>+{product.imageUrls.length - 5}</div>}
              </div>
            )}
            {product.dna.length > 0 && editing !== product.id && (
              <div>
                <div style={{ fontSize: 10, fontWeight: 700, color: c.textTer, letterSpacing: "0.07em", textTransform: "uppercase", marginBottom: 10 }}>Product DNA</div>
                <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(150px, 1fr))", gap: 8 }}>
                  {product.dna.map(d => (
                    <div key={d.label} style={{ background: c.bgAlt, borderRadius: 7, padding: "10px 12px", border: `1px solid ${c.border}` }}>
                      <div style={{ fontSize: 10, color: c.textTer, marginBottom: 3, textTransform: "uppercase", letterSpacing: "0.05em" }}>{d.label}</div>
                      <div style={{ fontSize: 12, fontWeight: 500, color: c.text }}>{d.value}</div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </Card>
        ))}
      </div>
    </div>
  );
}

// ─── History Screen ───────────────────────────────────────────────────────────
function History({ onNav }: { onNav: (s: Screen) => void }) {
  const [filter, setFilter] = useState<"all" | "ready" | "warning" | "critical">("all");
  const filtered = ALL_CHECKS.filter(r => filter === "all" || r.status === filter);

  function StatusBadge({ row }: { row: typeof ALL_CHECKS[0] }) {
    if (row.status === "ready")
      return <span style={{ background: c.greenLight, color: c.greenDark, padding: "3px 11px", borderRadius: 20, fontSize: 12, fontWeight: 600 }}>Ready</span>;
    if (row.status === "warning")
      return (
        <span style={{ background: c.amberLight, color: c.amberDark, padding: "3px 11px", borderRadius: 20, fontSize: 12, fontWeight: 600, display: "inline-flex", alignItems: "center", gap: 4 }}>
          <svg width="10" height="10" viewBox="0 0 12 12" fill="none"><path d="M6 1.5L10.5 10H1.5L6 1.5Z" stroke={c.amberDark} strokeWidth="1.3" strokeLinejoin="round"/><path d="M6 5v2" stroke={c.amberDark} strokeWidth="1.2" strokeLinecap="round"/><circle cx="6" cy="8.5" r="0.55" fill={c.amberDark}/></svg>
          {row.issues}
        </span>
      );
    return <span style={{ background: c.redLight, color: c.redDark, padding: "3px 11px", borderRadius: 20, fontSize: 12, fontWeight: 600 }}>Fix</span>;
  }

  const FILTERS = [
    { id: "all",      label: "All" },
    { id: "ready",    label: "Ready" },
    { id: "warning",  label: "Issues" },
    { id: "critical", label: "Fix needed" },
  ] as const;

  return (
    <div style={{ padding: "28px 32px", maxWidth: 820 }}>
      {/* Header */}
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 22 }}>
        <div>
          <div style={{ fontWeight: 700, fontSize: 20, color: c.text, letterSpacing: -0.3 }}>History</div>
          <div style={{ fontSize: 13, color: c.textSec, marginTop: 2 }}>{ALL_CHECKS.length} checks total</div>
        </div>
        <Btn small onClick={() => onNav("new-check")}>+ New Check</Btn>
      </div>

      {/* Filter pills */}
      <div style={{ display: "flex", gap: 6, marginBottom: 18 }}>
        {FILTERS.map(f => (
          <button key={f.id} onClick={() => setFilter(f.id)}
            style={{ padding: "5px 14px", borderRadius: 20, border: `1px solid ${filter === f.id ? "#111827" : c.border}`, background: filter === f.id ? "#111827" : c.bg, color: filter === f.id ? "#fff" : c.textSec, fontFamily: "var(--font-sans)", fontSize: 12, fontWeight: filter === f.id ? 600 : 400, cursor: "pointer" }}>
            {f.label}
            {f.id !== "all" && (
              <span style={{ marginLeft: 5, opacity: 0.7 }}>
                {ALL_CHECKS.filter(r => r.status === f.id).length}
              </span>
            )}
          </button>
        ))}
      </div>

      {/* List */}
      <div style={{ background: c.bg, border: `1px solid ${c.border}`, borderRadius: 12, overflow: "hidden", boxShadow: c.shadow }}>
        <div style={{ padding: "10px 20px", borderBottom: `1px solid ${c.border}`, display: "grid", gridTemplateColumns: "1fr 60px 90px 70px", gap: 8 }}>
          {["Creative", "Score", "Status", ""].map(h => (
            <div key={h} style={{ fontSize: 11, fontWeight: 700, color: c.textTer, textTransform: "uppercase", letterSpacing: "0.06em" }}>{h}</div>
          ))}
        </div>

        {filtered.length === 0 ? (
          <div style={{ padding: "40px 20px", textAlign: "center", color: c.textTer, fontSize: 13 }}>No checks match this filter.</div>
        ) : (
          filtered.map((row, i) => {
            const scoreColor = row.score >= 85 ? c.green : row.score >= 70 ? c.amber : c.red;
            return (
              <div key={row.id}
                onClick={() => onNav("results")}
                style={{ display: "grid", gridTemplateColumns: "1fr 60px 90px 70px", gap: 8, alignItems: "center", padding: "12px 20px", borderBottom: i < filtered.length - 1 ? `1px solid ${c.border}` : "none", cursor: "pointer", transition: "background 0.1s" }}
                onMouseEnter={e => (e.currentTarget.style.background = c.bgAlt)}
                onMouseLeave={e => (e.currentTarget.style.background = "transparent")}
              >
                {/* name + meta */}
                <div style={{ display: "flex", alignItems: "center", gap: 10, minWidth: 0 }}>
                  <div style={{ width: 30, height: 30, borderRadius: 7, background: c.bgTer, border: `1px solid ${c.border}`, flexShrink: 0, display: "flex", alignItems: "center", justifyContent: "center" }}>
                    <svg width="12" height="14" viewBox="0 0 12 14" fill="none">
                      <rect x="1" y="1" width="10" height="12" rx="1.5" stroke={c.textTer} strokeWidth="1.2"/>
                      <path d="M3 5h6M3 7.5h4" stroke={c.textTer} strokeWidth="1" strokeLinecap="round"/>
                    </svg>
                  </div>
                  <div style={{ minWidth: 0 }}>
                    <div style={{ fontSize: 14, fontWeight: 600, color: c.text, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{row.name}</div>
                    <div style={{ fontSize: 11, color: c.textTer, marginTop: 1 }}>{row.brand} · {row.date}</div>
                  </div>
                </div>
                {/* score */}
                <span style={{ fontFamily: "var(--font-mono)", fontSize: 14, fontWeight: 700, color: scoreColor }}>{row.score}</span>
                {/* badge */}
                <div><StatusBadge row={row} /></div>
                {/* action */}
                <div style={{ display: "flex", gap: 5, justifyContent: "flex-end" }}>
                  <Btn variant="ghost" small onClick={() => onNav("results")}>View</Btn>
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
}

// ─── App Shell ────────────────────────────────────────────────────────────────
export default function App() {
  const [screen, setScreen] = useState<Screen>("dashboard");

  function renderScreen() {
    const wrap = (node: React.ReactNode) => <div style={{ flex: 1, overflowY: "auto", background: c.bgAlt }}>{node}</div>;
    switch (screen) {
      case "dashboard":       return <Dashboard onNav={setScreen} />;
      case "projects":        return wrap(<div style={{ padding: 28 }}><TabProjects onNav={setScreen} /></div>);
      case "settings":        return wrap(<div style={{ padding: 28 }}><TabSettings /></div>);
      case "new-check":       return wrap(<NewCheck onNav={setScreen} />);
      case "analysis":        return <div style={{ flex: 1, display: "flex", background: c.bg }}><Analysis onNav={setScreen} /></div>;
      case "history":         return wrap(<History onNav={setScreen} />);
      case "results":         return wrap(<Results onNav={setScreen} />);
      case "issues":          return wrap(<IssuesDetail onNav={setScreen} />);
      case "fix-preview":     return wrap(<FixPreview onNav={setScreen} />);
      case "fix-processing":  return wrap(<FixProcessing onNav={setScreen} />);
      case "fix-results":     return wrap(<FixResults onNav={setScreen} />);
      case "brand-kit":       return wrap(<BrandKit onNav={setScreen} />);
      case "product-library": return wrap(<ProductLibrary onNav={setScreen} />);
    }
  }

  return (
    <div style={{ display: "flex", height: "100%", overflow: "hidden", background: c.bgAlt }}>
      <Sidebar active={screen} onNav={setScreen} />
      <main style={{ flex: 1, overflowY: "auto", display: "flex", flexDirection: "column" }}>
        {renderScreen()}
      </main>
    </div>
  );
}
