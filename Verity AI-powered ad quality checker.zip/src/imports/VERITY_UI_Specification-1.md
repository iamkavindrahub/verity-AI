# VERITY — UI/UX Specification

**Product**: VERITY (formerly CreativeCheck)  
**Tagline**: "Ensure your AI ads show the real product"  
**Status**: Ready for Figma design  
**Timeline**: 10 screens → Figma prototype (2-3 weeks)

---

## 1. DESIGN SYSTEM

### 1.1 Color Palette

**Background & Neutral:**
```
BG Primary:     #FFFFFF
BG Secondary:   #F9F9F9 (alt sections, cards)
BG Tertiary:    #F3F3F3 (hover, disabled)
Text Primary:   #1A1A1A (headlines, body)
Text Secondary: #666666 (labels, help text)
Text Tertiary:  #999999 (disabled, placeholder)
Border:         #E5E5E5 (dividers, card borders)
Border Dark:    #D1D1D1 (focus states, active)
```

**Status Colors (Primary visual language):**
```
Status Red:     #DC2626 (critical, don't publish)
Red Light:      #FEE2E2 (background)
Red Dark:       #991B1B (text)

Status Amber:   #EA8E1A (warning, review)
Amber Light:    #FEF3C7 (background)
Amber Dark:     #92400E (text)

Status Green:   #16A34A (ready, good)
Green Light:    #DCFCE7 (background)
Green Dark:     #166534 (text)

Status Gray:    #6B7280 (processing, info)
Gray Light:     #F3F4F6 (background)
Gray Dark:      #374151 (text)
```

**Interactive:**
```
Black:          #000000 (primary CTA, focus)
Gray Interactive: #F9F9F9 (hover state, secondary)
```

### 1.2 Typography

**Font Stack:**
```
Primary Font:   Inter (Google Fonts)
Mono Font:      JetBrains Mono (for code/data)
```

**Type Scale:**

| Role | Size | Weight | Line Height | Letter Spacing |
|------|------|--------|-------------|---|
| H1 (Page title) | 32px | 600 | 1.2 | -0.01em |
| H2 (Section title) | 24px | 600 | 1.3 | -0.005em |
| H3 (Card title) | 18px | 600 | 1.4 | 0 |
| Body Large | 16px | 400 | 1.5 | 0 |
| Body | 14px | 400 | 1.5 | 0 |
| Small | 12px | 400 | 1.4 | 0 |
| Label | 12px | 500 | 1.4 | 0.05em |
| Mono (data) | 13px | 400 | 1.5 | 0 |

### 1.3 Spacing System

```
4px   = xs
8px   = sm
12px  = md
16px  = lg
24px  = xl
32px  = 2xl
48px  = 3xl
64px  = 4xl
```

### 1.4 Component Rules

**Buttons**

Primary (CTA):
```
Background:  #000000
Text:        #FFFFFF
Padding:     12px 24px
Border:      none
Border-radius: 6px
Font-weight: 600
Font-size:   14px
Cursor:      pointer

Hover:       #1A1A1A
Active:      #000000 + 0.8 opacity
Disabled:    #D1D1D1, text #999
```

Secondary:
```
Background:  #F9F9F9
Text:        #1A1A1A
Border:      1px solid #E5E5E5
Padding:     12px 24px
Border-radius: 6px

Hover:       #F3F3F3
Active:      #E5E5E5
```

Danger:
```
Background:  #DC2626
Text:        #FFFFFF
Padding:     12px 24px
Border:      none
Border-radius: 6px

Hover:       #B91C1C
Active:      #991B1B
```

**Cards**

```
Background:  #FFFFFF
Border:      1px solid #E5E5E5
Border-radius: 8px
Padding:     20px
Shadow:      none (never use shadow)
Hover:       1px solid #D1D1D1 (optional, subtle)
```

**Inputs**

```
Background:  #FFFFFF
Border:      1px solid #E5E5E5
Border-radius: 6px
Padding:     10px 12px
Font-size:   14px
Font-family: Inter

Focus:       2px solid #000000
Focus outline: none (use border)
Placeholder: #999999
Text color:  #1A1A1A

Disabled:    #F9F9F9 background, #999 text
Error:       1px solid #DC2626
```

**Status Badges**

Red Badge:
```
Background:  #FEE2E2
Border:      none
Text:        #991B1B
Padding:     4px 8px
Border-radius: 4px
Font-size:   12px
Font-weight: 500
```

Amber Badge:
```
Background:  #FEF3C7
Text:        #92400E
(same padding/radius)
```

Green Badge:
```
Background:  #DCFCE7
Text:        #166534
(same padding/radius)
```

**Icons**

- Use **Feather Icons** (simple, clean, 20px default size)
- Stroke: 1.5px
- No filled icons (always outline)
- Color: inherit text color
- Hover: same, slight opacity shift (never change color)

**Dividers**

```
Horizontal:  1px solid #E5E5E5
Spacing:     16px above/below
Vertical:    1px solid #E5E5E5 (for layouts)
```

---

## 2. SCREEN SPECIFICATIONS

### Screen 1: Dashboard

**Layout:** 3-column grid
- Left sidebar (navigation)
- Main content (dashboard)
- Right panel (optional: quick stats)

**Header:**
```
[VERITY Logo] Dashboard

Welcome, [User Name]
Workspace: [Workspace Name] [Manage]
```

**Tab Navigation:**
```
Overview | Projects | Brand Kit | Settings
```

**Overview Content:**

Section 1: Quick Stats
```
┌─────────────────────────────────────────────────────────┐
│ Checks This Month    Avg Score    Ready to Publish      │
│      12 / 100         82/100           75%              │
│                                                          │
│ Last Check: Travel Campaign (84/100) ✓ Ready            │
└─────────────────────────────────────────────────────────┘
```

Section 2: Recent Creatives (Table)
```
┌──────────────────────────────────────────────────────────────────────┐
│ Creative                 Score    Status         Date      Action    │
├──────────────────────────────────────────────────────────────────────┤
│ Travel Campaign          84/100   ⚠ 3 issues     Sep 2     [View]   │
│ Summer Launch            93/100   ✓ Ready        Sep 1     [View]   │
│ Facebook Ad #12          67/100   🔴 Fix req.    Aug 31    [Fix]    │
│ Instagram Post           78/100   ⚠ 2 issues     Aug 30    [View]   │
└──────────────────────────────────────────────────────────────────────┘
```

**Right Panel (Optional):**
```
📊 Performance This Month
─────────────────────────
Avg Score: 82/100
Ready: 75% ✓
Issues Found: 18
Fixes Applied: 4

Plan: Designer
Checks: 12/100
Upgrade →
```

---

### Screen 2: New Check — Upload

**Header:**
```
New Creative Check

Upload your AI-generated advertisement and product references
to check if everything is accurate and ready to publish.
```

**Layout:** Two-column (side-by-side dropzones)

**Left Column: Product Reference**

```
Heading: "Product Reference"
Subtext: "Upload 1-5 photos of your actual product"

┌────────────────────────────────────────┐
│                                        │
│          📷 Drop images here           │
│                                        │
│            or click to upload          │
│                                        │
│      JPG, PNG • Max 5 images           │
└────────────────────────────────────────┘

✅ When uploaded:
├─ Image 1.jpg (1.2 MB)
├─ Image 2.jpg (0.8 MB)
└─ [+ Add more]

[Reset]
```

**Right Column: Advertisement**

```
Heading: "Advertisement Creative"
Subtext: "The AI-generated ad you want to check"

┌────────────────────────────────────────┐
│                                        │
│          🖼️ Drop creative here         │
│                                        │
│            or click to upload          │
│                                        │
│      JPG, PNG • Max 10 MB              │
└────────────────────────────────────────┘

✅ When uploaded:
└─ Facebook_Ad_Final.png (2.4 MB)

[Reset]
```

**Meta Section Below:**

```
Campaign (optional)
┌──────────────────────────────────┐
│ Select or create campaign    ▼  │
│ [Create new campaign...          │
└──────────────────────────────────┘

Brand Profile (required)
┌──────────────────────────────────┐
│ Select brand to check against ▼ │
│ ○ Exchange Life (2 products)    │
│ ○ Luxury Brand Corp             │
│ ○ Minimal Design Co.            │
│ [Create new...]                 │
└──────────────────────────────────┘
```

**Bottom CTA:**

```
[CANCEL]  [ANALYZE] (disabled until both files uploaded)
```

---

### Screen 3: Analysis (Loading State)

**Fullscreen overlay or dedicated page**

```
Center of screen:

┌─────────────────────────────┐
│                             │
│  Analyzing your creative    │
│  Please wait...             │
│                             │
│  ━━━━━━━━━  60%             │
│                             │
│  • Extracting product data  │
│  • Checking brand rules     │
│  • Validating readability   │
│  → Generating recommendations
│                             │
│  Estimated: 20 seconds      │
│                             │
└─────────────────────────────┘
```

**Do NOT use:**
- Spinning loaders
- Animated progress (static text progress instead)
- Flashy animations
- "AI is thinking" messaging

---

### Screen 4: Results (Hero Screen)

**Layout:** Two-column hero
- **Left (50%):** Creative thumbnail
- **Right (50%):** Score card

**Left Column: Visual**

```
┌──────────────────────────────────┐
│                                  │
│      [Creative Image Preview]    │
│      (600x400 placeholder)       │
│                                  │
│      ✓ Product visible           │
│      ✓ Brand consistency         │
│      ⚠ 3 issues found            │
│                                  │
└──────────────────────────────────┘

[Download] [View Full Image] [Compare]
```

**Right Column: Score Card**

```
CREATIVE READY SCORE

        84
       ───
       100

[✓ READY TO PUBLISH] 
or
[🔴 DO NOT PUBLISH — Fix 3 issues first]

─────────────────────────────────────

Score Breakdown

Product Accuracy       91  ✓
Brand Consistency      96  ✓
AI Quality             73  ⚠
Readability            82  
Compliance             88  ✓

─────────────────────────────────────

3 Issues Found

[View Issues] [Fix Issues]
```

**Below Hero:**

```
Issues Summary

🔴 CRITICAL (1)
   └─ Product
      Logo differs from approved reference

🟠 WARNING (2)
   ├─ Design
   │  CTA becomes difficult to read at mobile size
   └─ AI Quality
      Charm connection appears physically impossible
```

**Action Buttons:**

```
[← Back] [View Full Report] [Fix Issues] [Download]
```

---

### Screen 5: Issues Detail

**Table/List View of all issues**

```
Header:
Issues Found (3 total)

┌────────────────────────────────────────────────────────┐
│ ┌─ 🔴 PRODUCT                          FIXABLE ✓      │
│ │ Logo differs from approved reference                │
│ │ Confidence: 94%                                     │
│ │                                                      │
│ │ Why this matters:                                   │
│ │ Your logo is the key identifier for your brand.     │
│ │ Inconsistent logos reduce recognition across ads.  │
│ │                                                      │
│ │ [VIEW LOCATION ON IMAGE] [FIX THIS ISSUE]          │
│ └────────────────────────────────────────────────────│
│                                                        │
│ ┌─ 🟠 DESIGN                          NOT FIXABLE     │
│ │ CTA becomes difficult to read at mobile size        │
│ │ Confidence: 87%                                     │
│ │                                                      │
│ │ Suggested action: Manual redesign required          │
│ │ Increase button size or relocate CTA               │
│ │                                                      │
│ │ [VIEW LOCATION ON IMAGE] [DISMISS]                │
│ └────────────────────────────────────────────────────│
│                                                        │
│ ┌─ 🟠 AI QUALITY                      FIXABLE ✓      │
│ │ Charm connection appears physically impossible     │
│ │ Confidence: 87%                                     │
│ │                                                      │
│ │ [VIEW LOCATION ON IMAGE] [FIX THIS ISSUE]         │
│ └────────────────────────────────────────────────────│
└────────────────────────────────────────────────────────┘
```

**Sidebar (Optional):**

```
Filter by:
○ All (3)
○ Critical (1)
○ Warning (2)
○ Fixable (2)
○ Manual Only (1)
```

---

### Screen 6: Fix Preview

**Before user commits to fixes, show what's available**

```
Header:
Fix Preview

We can automatically fix 2 out of 3 issues.
Estimated new score: 91/100 (+7 points)

┌─────────────────────────────────────────────────────────┐
│ Fixable Issues (2)                                      │
├─────────────────────────────────────────────────────────┤
│ ✓ Product                                               │
│   Logo color correction                                 │
│   Est. quality: 92/100                                 │
│   Est. time: 15 seconds                                │
│                                                         │
│ ✓ AI Quality                                            │
│   Blur charm connection artifact                        │
│   Est. quality: 88/100                                 │
│   Est. time: 10 seconds                                │
│                                                         │
│ [AUTO-FIX ALL 2 ISSUES] [SELECT INDIVIDUAL FIXES]      │
└─────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────┐
│ Manual-Only Issues (1)                                  │
├─────────────────────────────────────────────────────────┤
│ ⚠ Design                                                │
│   CTA readability at mobile size                        │
│   Requires: Redesign (manual work)                      │
│   Status: Cannot auto-fix                              │
└─────────────────────────────────────────────────────────┘

Summary
─────────────────────────────────────────────────────────
Current Score:      84/100
Fixable Score:      91/100 (+7)
Manual Remaining:   1 issue
Total Time:         ~25 seconds

[CANCEL] [PREVIEW FIXES] [AUTO-FIX ALL]
```

---

### Screen 7: Fix Processing (Loading State)

**Real-time progress view**

```
Header:
Fixing your creative

Status: Processing (2 of 2)

┌─────────────────────────────────────────────────────────┐
│ ✓ COMPLETED                                             │
│   Product Logo Color Correction                         │
│   Confidence: 94%                                       │
│   ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ 100%                  │
│                                                         │
│   Before: [Thumbnail]  After: [Thumbnail]              │
│                                                         │
│   [Image appears correct]                              │
├─────────────────────────────────────────────────────────┤
│ ⏳ PROCESSING                                            │
│   Charm Connection Blur                                │
│   ━━━━━━━━━━━━─ 60%                                    │
│   Estimated: 4 seconds remaining                       │
├─────────────────────────────────────────────────────────┤
│ ⏹ QUEUED                                                │
│   (Next fix will start after current completes)        │
└─────────────────────────────────────────────────────────┘

[CANCEL] [↓ Pause]
```

---

### Screen 8: Fix Results & Before/After

**Post-fix comparison screen**

```
Header:
All fixes complete

New Score: 91/100 (+7 points)
Status: ✓ READY TO PUBLISH

┌──────────────────────────────┬──────────────────────────┐
│ BEFORE                       │ AFTER                    │
│ (Original)                   │ (Fixed)                  │
│                              │                          │
│ [Full image]                 │ [Full image]             │
│ 84/100                       │ 91/100                   │
│                              │                          │
│ Issues: 3                    │ Issues: 1 (manual only) │
└──────────────────────────────┴──────────────────────────┘

Fixes Applied (2)
┌─────────────────────────────────────────────────────────┐
│ ✓ Product Logo Color Corrected                          │
│   Confidence: 94%                                       │
│   Applied: Gradient correction (gold tones)             │
│   [Details]                                             │
│                                                         │
│ ✓ Charm Connection Artifact Blurred                     │
│   Confidence: 87%                                       │
│   Applied: Gaussian blur + refinement                   │
│   [Details]                                             │
└─────────────────────────────────────────────────────────┘

Remaining Issues (1)
┌─────────────────────────────────────────────────────────┐
│ ⚠ CTA Readability (mobile)                              │
│   Status: Manual fix required                          │
│   Suggestion: Increase button size or reposition       │
└─────────────────────────────────────────────────────────┘

Actions
┌─────────────────────────────────────────────────────────┐
│ [DISCARD & START OVER] [USE FIXED VERSION] [DOWNLOAD]  │
└─────────────────────────────────────────────────────────┘
```

---

### Screen 9: Brand Kit

**Brand profile setup/management**

```
Header:
Brand Kit

Manage your brand profile and rules

Tabs:
○ Overview | Rules | Product | Visual Style

OVERVIEW TAB:
┌──────────────────────────────────────────────────────────┐
│ Brand Name                                               │
│ ┌─────────────────────────────────────────────────────┐ │
│ │ Exchange Life                                       │ │
│ └─────────────────────────────────────────────────────┘ │
│                                                          │
│ Logo Upload                                              │
│ ┌─────────────────────────────────────────────────────┐ │
│ │ [Logo Preview]  [Change] [Remove]                  │ │
│ └─────────────────────────────────────────────────────┘ │
└──────────────────────────────────────────────────────────┘

RULES TAB:
┌──────────────────────────────────────────────────────────┐
│ Color Palette                                            │
│                                                          │
│ Primary Colors                                           │
│ ⬛ Gold       #D4AF37                                    │
│ ⬛ Navy       #1A1F36                                    │
│ ⬛ Cream      #F5F1ED                                    │
│ [+ Add color]                                           │
│                                                          │
│ Typography                                               │
│ Headline Font: Serif (Georgia)                          │
│ Body Font: Sans-serif (Inter)                           │
│ [Edit]                                                  │
│                                                          │
│ Visual Style (Select all that apply)                     │
│ ☑ Editorial      ☑ Premium       ☐ Minimal             │
│ ☑ Travel         ☐ Bold          ☐ Playful             │
│ [✓ Warm tone]    ☐ Dark          ☐ Neon               │
│                                                          │
│ [SAVE]                                                  │
└──────────────────────────────────────────────────────────┘
```

---

### Screen 10: Product Library

**Manage product references**

```
Header:
Product Library

Manage product references for your brand

┌──────────────────────────────────────────────────────────┐
│ Exchange Life Keychain                                   │
│ 12 reference images                                      │
│                                                          │
│ Product DNA Extracted:                                   │
│ • Shape: Rectangular pendant                             │
│ • Materials: Resin + gold metal                          │
│ • Colors: Gold, navy, cream                              │
│ • Dimensions: ~2cm x 3cm                                 │
│ • Key Features: Direct clasp, glossy finish              │
│                                                          │
│ [View Images] [Edit] [Delete]                           │
└──────────────────────────────────────────────────────────┘

┌──────────────────────────────────────────────────────────┐
│ Gold Charm                                               │
│ 8 reference images                                       │
│                                                          │
│ Product DNA Extracted:                                   │
│ • Shape: Circular disc                                   │
│ • Materials: 14k gold plated                             │
│ • Colors: Gold, champagne                                │
│ • Dimensions: ~1.5cm diameter                            │
│ • Key Features: Smooth, shiny finish                     │
│                                                          │
│ [View Images] [Edit] [Delete]                           │
└──────────────────────────────────────────────────────────┘

[+ Add New Product]
```

---

## 3. NAVIGATION STRUCTURE

### Main Navigation (Left Sidebar)

```
┌─────────────────────────────┐
│ [V] VERITY                  │
├─────────────────────────────┤
│ Dashboard          [📊]     │
│ New Check          [➕]     │
│ History            [📋]     │
│ Projects           [📁]     │
│                             │
├─────────────────────────────┤
│ Settings           [⚙️]     │
│ Brand Kit          [🎨]     │
│ Product Library    [📦]     │
│ Team               [👥]     │
│                             │
├─────────────────────────────┤
│ Help               [❓]     │
│ Docs               [📖]     │
│ Contact            [💬]     │
│                             │
├─────────────────────────────┤
│ [User Profile]     [👤]     │
│ [Upgrade Plan]     [⬆️]     │
│ [Sign Out]         [🚪]     │
└─────────────────────────────┘
```

### Primary User Flow

```
Dashboard
    ↓
[+ New Check]
    ↓
Upload Screen (product + creative)
    ↓
Analysis (loading)
    ↓
Results (score + issues)
    ↓
[Fix Issues] or [Download/Share]
    ├─ Fix Preview
    ├─ Fix Processing
    └─ Fix Results + Before/After
    ↓
[Approve & Use Fixed Version]
    ↓
Back to Dashboard (history updated)
```

---

## 4. MICRO-INTERACTIONS & ANIMATIONS

**Philosophy:** Minimal, purposeful, never decorative

### Transitions
- Page transitions: 200ms fade
- Modal/overlay: 150ms slide up
- Button hover: 100ms opacity change

### Loading States
- Text-based progress (avoid spinners)
- Real-time status updates
- Estimated time remaining

### Status Changes
- Status badge color changes (instant, no animation)
- Score update (number tween over 300ms)
- Issue resolution (fade out solved issues)

### Form Interactions
- Input focus: 2px solid border (no animation)
- Dropdown open: instant
- Form submission: disable button, show loading text

---

## 5. RESPONSIVE DESIGN

**Breakpoints:**
```
Desktop:    1280px+
Tablet:     768px - 1279px
Mobile:     320px - 767px
```

**Key Adjustments:**

Mobile (Hero Screen):
- One-column layout (creative top, score card below)
- Full-width dropzones
- Larger touch targets (44px minimum)
- Vertical card layout

Tablet:
- Two-column where possible
- Adjusted padding (16px vs 20px)
- Table converts to card list view

---

## 6. ACCESSIBILITY (WCAG 2.1 AA)

```
✅ Color Contrast
   - Text vs background: 4.5:1 minimum
   - UI components: 3:1 minimum
   - Check: Status colors + white text meet contrast

✅ Keyboard Navigation
   - Tab through all interactive elements
   - Tab order follows visual flow
   - Focus indicators: 2px solid #000000

✅ Screen Readers
   - Semantic HTML (button, input, label)
   - ARIA labels for ambiguous elements
   - Form fields have associated labels

✅ Touch Targets
   - Minimum 44x44px for mobile
   - Spacing between targets: 8px minimum

✅ Motion
   - No auto-playing animations
   - Respect prefers-reduced-motion
```

---

## 7. INTERACTION FLOWS

### Flow 1: New User Sign Up to First Check

```
1. Sign Up (email + password)
   ↓
2. Create Workspace
   ↓
3. Onboarding: Setup Brand Kit (optional, can skip)
   ├─ Logo upload
   ├─ Color palette
   └─ Product library (optional)
   ↓
4. Dashboard (empty state)
   ↓
5. [+ New Check] (guide user)
   ↓
6. Complete first analysis
   ↓
7. Result + onboarding: "Try fixing issues"
```

### Flow 2: Fix Issue Workflow

```
1. [Fix Issues] button from results
   ↓
2. Fix Preview screen
   ├─ Show fixable issues
   ├─ Estimate time + score improvement
   └─ [Auto-fix all] or [Select individual]
   ↓
3. Fix Processing
   ├─ Real-time status
   ├─ Before/after previews
   └─ Progress updates
   ↓
4. Fix Results screen
   ├─ Before/after comparison
   ├─ List of applied fixes
   └─ Remaining manual issues
   ↓
5. [Use Fixed Version] or [Discard]
   ├─ If use: Replace original, mark as "fixed"
   └─ If discard: Return to results
```

### Flow 3: Brand Management

```
1. [Brand Kit] from sidebar
   ↓
2. Overview: See current brand profile
   ↓
3. [Edit] → Rules tab
   ├─ Update colors
   ├─ Update typography
   └─ Update visual style
   ↓
4. [Save]
   ↓
5. All future checks use updated rules
```

---

## 8. DESIGN TOKENS (Figma Variables)

```
Colors/
├─ Background/
│  ├─ Primary (#FFFFFF)
│  ├─ Secondary (#F9F9F9)
│  └─ Tertiary (#F3F3F3)
├─ Text/
│  ├─ Primary (#1A1A1A)
│  ├─ Secondary (#666666)
│  └─ Tertiary (#999999)
├─ Status/
│  ├─ Critical (#DC2626)
│  ├─ Warning (#EA8E1A)
│  ├─ Success (#16A34A)
│  └─ Info (#6B7280)
└─ Interactive/
   ├─ Black (#000000)
   └─ Borders (#E5E5E5)

Typography/
├─ Heading/
│  ├─ H1 (32px / 600 / -0.01em)
│  ├─ H2 (24px / 600 / -0.005em)
│  └─ H3 (18px / 600 / 0)
├─ Body/
│  ├─ Large (16px / 400 / 0)
│  ├─ Regular (14px / 400 / 0)
│  └─ Small (12px / 400 / 0)
└─ Label (12px / 500 / 0.05em)

Spacing/
├─ xs (4px)
├─ sm (8px)
├─ md (12px)
├─ lg (16px)
├─ xl (24px)
├─ 2xl (32px)
├─ 3xl (48px)
└─ 4xl (64px)

Radius/
├─ sm (4px)
├─ md (6px)
└─ lg (8px)

Shadows/
└─ None (design principle: never use box-shadow)
```

---

## 9. FIGMA FILE STRUCTURE

```
VERITY Design System
├─ 🎨 Brand
│  ├─ Logo
│  ├─ Colors
│  └─ Typography
├─ 🧩 Components
│  ├─ Buttons
│  ├─ Inputs
│  ├─ Cards
│  ├─ Badges
│  ├─ Modals
│  └─ Navigation
├─ 📱 Screens
│  ├─ 01-Dashboard
│  ├─ 02-New Check
│  ├─ 03-Analysis
│  ├─ 04-Results
│  ├─ 05-Issues Detail
│  ├─ 06-Fix Preview
│  ├─ 07-Fix Processing
│  ├─ 08-Fix Results
│  ├─ 09-Brand Kit
│  └─ 10-Product Library
├─ 🔄 Flows
│  ├─ New User Onboarding
│  ├─ New Check Flow
│  ├─ Fix Issue Flow
│  └─ Brand Management Flow
└─ 📐 Dev Handoff
   ├─ Component Specs
   ├─ Spacing Guide
   ├─ Animation Guide
   └─ Responsive Breakpoints
```

---

## 10. EMPTY STATES & EDGE CASES

### Empty Dashboard (First User)

```
┌──────────────────────────────────────────────────────┐
│ Welcome to VERITY                                    │
│                                                      │
│ Ready to check your first creative?                  │
│                                                      │
│ [📸 Upload Product Photos]                          │
│ [🖼️ Upload Your First Creative]                      │
│                                                      │
│ [+ New Check] (primary CTA)                         │
│                                                      │
│ How it works:                                        │
│ 1. Upload AI-generated ad + product photos           │
│ 2. VERITY analyzes accuracy & readiness              │
│ 3. Fix issues or download report                    │
└──────────────────────────────────────────────────────┘
```

### Error State (Upload Failed)

```
┌──────────────────────────────────────────────────────┐
│ 🔴 Upload Failed                                     │
│                                                      │
│ File too large (max 10 MB)                          │
│ Your file: 15 MB                                    │
│                                                      │
│ [Compress & Retry] [Try Different File]             │
└──────────────────────────────────────────────────────┘
```

### No Issues Found (Perfect Creative)

```
┌──────────────────────────────────────────────────────┐
│ ✓ PERFECT SCORE                                      │
│ 100/100                                              │
│                                                      │
│ No issues detected. Your creative is ready!         │
│                                                      │
│ [Download] [Check Another Creative] [Share]         │
└──────────────────────────────────────────────────────┘
```

---

## 11. COPY & MESSAGING

### Key Messages

**When analysis is perfect:**
```
"Your creative is ready to publish. No issues detected."
```

**When fixes are available:**
```
"We can automatically fix 2 of 3 issues. New score: 91/100."
```

**When manual work is needed:**
```
"This issue requires manual redesign. Here's why and what to change."
```

**Error messages (never generic):**
```
❌ "Product color is navy, but your brand standard is gold."
(not: "Brand consistency check failed")

❌ "Logo differs from approved version by 23%."
(not: "Logo accuracy issue detected")
```

### Buttons & CTAs

```
Primary action:        "ANALYZE" / "FIX ISSUES" / "USE FIXED VERSION"
Secondary action:      "Preview" / "Compare" / "Download"
Destructive action:    "Delete Check" / "Discard Fixes"
Neutral action:        "Cancel" / "Skip" / "Dismiss"
```

---

## 12. SUCCESS METRICS FOR DESIGN

Once built, measure:

```
✅ Time to first check: < 2 minutes
✅ Clarity of score: 90%+ users understand their score
✅ Fix adoption: % of users who use auto-fix feature
✅ Navigation clarity: < 2 clicks to any main feature
✅ Mobile usability: 90%+ task completion on mobile
✅ Accessibility: 100% WCAG 2.1 AA compliance
```

---

## 13. NEXT: HANDOFF TO ENGINEERING

When Figma design is complete, prepare:

1. **Component specs** (CSS classes, props)
2. **Color/type tokens** (CSS variables)
3. **Interaction specs** (hover, focus, disabled states)
4. **Responsive grid** (breakpoints, column widths)
5. **Animation specs** (timing, easing)
6. **Accessibility checklist** (ARIA labels, focus order)

