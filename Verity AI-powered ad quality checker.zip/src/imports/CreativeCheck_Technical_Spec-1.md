# CreativeCheck AI — Technical Specification

**Version**: 1.0  
**Status**: MVP Phase  
**Target Launch**: 8-12 weeks

---

## 1. PRODUCT OVERVIEW

**What it does:**
- Accepts AI-generated advertisements + product references
- Analyzes product accuracy, brand consistency, readability, compliance
- Returns a CREATIVE READY SCORE (0-100) + detailed issue breakdown
- Stores brand profiles for future checks

**What it does NOT do (MVP):**
- Generate images
- Remove backgrounds
- Create AI photoshoots
- Bulk image processing (Phase 2)

---

## 2. BACKEND ARCHITECTURE

### 2.1 Tech Stack

```
Language:        Node.js (Express.js)
Database:        PostgreSQL
Cache:           Redis (for brand profiles, recent checks)
Vision AI:       Claude Vision API (multimodal analysis)
File Storage:    AWS S3 or similar
Task Queue:      Bull (Redis-based job queue for async analysis)
Authentication:  JWT + API keys
Deployment:      Docker + AWS ECS/Railway/Render
```

### 2.2 Core Services

```
├── Auth Service
│   ├── User signup/login
│   ├── API key generation
│   └── Team/workspace management
│
├── Upload Service
│   ├── File validation
│   ├── S3 storage management
│   └── Image metadata extraction
│
├── Analysis Service
│   ├── Vision AI orchestration
│   ├── Scoring engine
│   ├── Rules engine
│   └── Report generation
│
├── Brand Service
│   ├── Brand profile CRUD
│   ├── Product reference management
│   ├── Brand rules storage
│   └── Brand DNA generation
│
├── Check Service
│   ├── Create check
│   ├── Retrieve check history
│   ├── List checks by project
│   └── Compare before/after
│
├── Fix Service
│   ├── Generate fix instructions
│   ├── Call Vision API for targeted fixes
│   ├── Upscale/enhance fixed areas
│   ├── Blend corrected elements
│   └── Store original + fixed versions
│
└── Webhook Service
    ├── Analysis completion webhooks
    ├── Fix completion webhooks
    └── Result delivery
```

---

## 3. DATABASE SCHEMA

### Users Table
```sql
CREATE TABLE users (
  id UUID PRIMARY KEY,
  email VARCHAR(255) UNIQUE NOT NULL,
  password_hash VARCHAR(255),
  name VARCHAR(255),
  plan VARCHAR(50), -- 'free', 'designer', 'agency'
  workspace_id UUID,
  created_at TIMESTAMP,
  updated_at TIMESTAMP,
  deleted_at TIMESTAMP
);
```

### Workspaces Table
```sql
CREATE TABLE workspaces (
  id UUID PRIMARY KEY,
  name VARCHAR(255) NOT NULL,
  slug VARCHAR(255) UNIQUE,
  owner_id UUID REFERENCES users(id),
  plan VARCHAR(50),
  monthly_checks_used INT DEFAULT 0,
  monthly_checks_limit INT,
  created_at TIMESTAMP,
  updated_at TIMESTAMP
);
```

### Brand Profiles Table
```sql
CREATE TABLE brand_profiles (
  id UUID PRIMARY KEY,
  workspace_id UUID REFERENCES workspaces(id),
  name VARCHAR(255) NOT NULL,
  
  -- Visual rules
  primary_colors JSONB, -- {hex: "#fff", name: "white"}
  secondary_colors JSONB,
  typography JSONB, -- {headline: "font-family", body: "font-family"}
  
  -- Product rules
  product_rules JSONB, -- {material: "gold", finish: "glossy"}
  visual_style JSONB, -- {premium: true, minimal: false}
  
  -- Brand DNA
  brand_dna JSONB,
  
  created_at TIMESTAMP,
  updated_at TIMESTAMP
);
```

### Product References Table
```sql
CREATE TABLE product_references (
  id UUID PRIMARY KEY,
  brand_profile_id UUID REFERENCES brand_profiles(id),
  product_name VARCHAR(255),
  
  -- Extracted features from reference images
  reference_images JSONB, -- {url: "s3://...", extracted_features: {...}}
  
  -- Vision AI extracted product DNA
  product_dna JSONB, -- {
  --   shape: "rectangular",
  --   colors: ["gold", "navy"],
  --   materials: ["resin", "metal"],
  --   dimensions: "approx 2cm x 3cm",
  --   distinguishing_features: [...]
  -- }
  
  created_at TIMESTAMP,
  updated_at TIMESTAMP
);
```

### Creative Checks Table
```sql
CREATE TABLE creative_checks (
  id UUID PRIMARY KEY,
  workspace_id UUID REFERENCES workspaces(id),
  brand_profile_id UUID REFERENCES brand_profiles(id),
  
  -- Uploaded files
  creative_image_url VARCHAR(500),
  reference_image_ids UUID[],
  
  -- Analysis results
  status VARCHAR(50), -- 'queued', 'analyzing', 'completed', 'failed'
  
  -- Scores (0-100)
  creative_ready_score INT,
  product_accuracy_score INT,
  brand_consistency_score INT,
  ai_quality_score INT,
  readability_score INT,
  compliance_score INT,
  
  -- Issues found
  issues JSONB, -- [{
  --   id: UUID,
  --   type: "product_mismatch" | "brand" | "ai_artifact" | "readability" | "compliance",
  --   severity: "red" | "amber" | "yellow",
  --   title: "string",
  --   description: "string",
  --   confidence: 0-100,
  --   location: {x, y, width, height} -- for pointing on image
  --   fixable: boolean,
  --   fix_method: "product_replace" | "color_correct" | "blur_artifact" | "enhance_text" | null
  -- }]
  
  -- Vision AI analysis details
  vision_analysis JSONB, -- Raw Claude Vision output
  
  -- Fixed versions (if user requested fixes)
  fixed_image_url VARCHAR(500),
  fix_status VARCHAR(50), -- 'not_attempted', 'processing', 'completed', 'failed'
  fixes_applied JSONB, -- [{issue_id, fix_method, quality_score, before_url, after_url}]
  
  ready_to_publish BOOLEAN,
  publish_reason VARCHAR(255),
  
  created_at TIMESTAMP,
  updated_at TIMESTAMP
);
```

### Projects Table
```sql
CREATE TABLE projects (
  id UUID PRIMARY KEY,
  workspace_id UUID REFERENCES workspaces(id),
  name VARCHAR(255),
  brand_profile_id UUID REFERENCES brand_profiles(id),
  description TEXT,
  
  created_at TIMESTAMP,
  updated_at TIMESTAMP
);
```

### Audit Log Table
```sql
CREATE TABLE audit_logs (
  id UUID PRIMARY KEY,
  workspace_id UUID,
  user_id UUID,
  action VARCHAR(100),
  resource_type VARCHAR(100),
  resource_id UUID,
  changes JSONB,
  created_at TIMESTAMP
);
```

---

## 4. API ENDPOINTS

### Authentication
```
POST   /auth/signup
POST   /auth/login
POST   /auth/refresh
GET    /auth/me
POST   /auth/api-keys
```

### Workspace
```
GET    /workspaces/:id
PUT    /workspaces/:id
GET    /workspaces/:id/usage
```

### Brand Profiles
```
GET    /workspaces/:id/brands
POST   /workspaces/:id/brands
GET    /workspaces/:id/brands/:brandId
PUT    /workspaces/:id/brands/:brandId
DELETE /workspaces/:id/brands/:brandId
```

### Product References
```
POST   /workspaces/:id/brands/:brandId/products
GET    /workspaces/:id/brands/:brandId/products
DELETE /workspaces/:id/brands/:brandId/products/:productId
POST   /workspaces/:id/brands/:brandId/products/:productId/extract
```

### Creative Checks (Core)
```
POST   /workspaces/:id/checks
       Body: {
         creative_image: File,
         reference_image_ids: [UUID],
         brand_profile_id: UUID,
         project_id: UUID (optional),
         webhook_url: string (optional)
       }

GET    /workspaces/:id/checks
GET    /workspaces/:id/checks/:checkId
GET    /workspaces/:id/checks/:checkId/details
GET    /workspaces/:id/checks/:checkId/comparison
DELETE /workspaces/:id/checks/:checkId
```

### Image Fixing
```
POST   /workspaces/:id/checks/:checkId/fix
       Body: {
         issue_ids: [UUID], -- which issues to fix
         auto_blend: boolean (default: true),
         upscale: boolean (default: false)
       }
       Returns: {
         fix_id: UUID,
         status: "processing",
         eta_seconds: 30
       }

GET    /workspaces/:id/checks/:checkId/fixes/:fixId
       Returns: {
         status: "completed" | "processing" | "failed",
         fixed_image_url: string,
         fix_details: [{issue_id, action_taken, quality_score}],
         comparison_url: string (side-by-side)
       }

GET    /workspaces/:id/checks/:checkId/fix-preview
       Returns: {
         fixes_available: [{issue_id, fixable: boolean, method: string}],
         total_fixable: number,
         estimated_time: seconds
       }

POST   /workspaces/:id/checks/:checkId/approve-fix
       Body: {fix_id: UUID}
       Returns: {replaced: boolean, new_creative_url: string}
```

### Projects
```
GET    /workspaces/:id/projects
POST   /workspaces/:id/projects
GET    /workspaces/:id/projects/:projectId/checks
```

---

## 5. SCORING LOGIC & ALGORITHMS

### 5.1 Overall Creative Ready Score

```
CREATIVE_READY_SCORE = (
  (product_accuracy × 0.35) +
  (brand_consistency × 0.25) +
  (ai_quality × 0.15) +
  (readability × 0.15) +
  (compliance × 0.10)
)

If any score is RED (< 40), READY_TO_PUBLISH = false
If any score is AMBER (40-70) and > 1, READY_TO_PUBLISH = false
Otherwise, READY_TO_PUBLISH = true (if > 70)
```

### 5.2 Product Accuracy Score

Uses Claude Vision to:
1. Extract product features from reference images
2. Extract product features from creative image
3. Compare feature-by-feature
4. Score similarity (0-100)

```
Features to compare:
- Shape & silhouette
- Color palette
- Logo presence & accuracy
- Packaging/materials
- Distinguishing details
- Dimensions (approximate)
- Number of components
- Hardware/clasp/closure

Scoring:
- 95-100: Perfect match
- 85-94:  Minor variations (acceptable)
- 70-84:  Noticeable differences
- 40-69:  Significant inaccuracies
- 0-39:   Product unrecognizable
```

### 5.3 Brand Consistency Score

Checks against brand profile rules:

```
- Logo accuracy (position, size, colors)       [20 pts]
- Color palette adherence                      [20 pts]
- Typography matching brand rules              [20 pts]
- Visual style match (premium/minimal/etc)     [20 pts]
- Overall brand alignment                      [20 pts]

Total: 100 pts
```

### 5.4 AI Quality Score

Detects AI artifacts:

```
- Unnatural textures/patterns                  [25 pts]
- Impossible geometry                          [25 pts]
- Distorted text/unreadable elements           [20 pts]
- Odd lighting/shadows                         [15 pts]
- Uncanny colors/gradients                     [15 pts]

Total: 100 pts
```

### 5.5 Readability Score

For mobile and desktop:

```
- Text contrast ratio (WCAG AA standard)       [25 pts]
- Font size adequacy (mobile 390px+)           [25 pts]
- CTA prominence                               [25 pts]
- Hierarchy clarity                            [25 pts]

Total: 100 pts
```

### 5.6 Compliance Score

Checks against rules:

```
- No unsupported claims (without disclaimer)   [30 pts]
- No prohibited images/content                 [30 pts]
- Platform-specific rules (if provided)        [20 pts]
- Legal text presence (if required)            [20 pts]

Total: 100 pts
```

### 5.7 Issue Severity Classification

```
🔴 RED (CRITICAL)
   - Product unrecognizable
   - Major brand violation
   - Compliance violation
   - Required disclaimer missing

🟠 AMBER (HIGH)
   - Noticeable product inaccuracy
   - Brand element wrong
   - Readability issue at mobile size

🟡 YELLOW (MEDIUM)
   - Minor visual inconsistency
   - Slight color variance
   - Non-critical compliance note
```

---

## 6. CLAUDE VISION ANALYSIS WORKFLOW

### 6.2 Image Fixing Methods

Not all issues can be auto-fixed. Classification:

```
🔧 FIXABLE (Auto-generate fixes)
- Product color correction
- Logo color adjustment
- Text contrast enhancement
- Minor blur/artifact removal
- Product swap (replace with correct reference)

⚠️ SEMI-FIXABLE (Needs user approval)
- Complex product shape changes
- Major recomposition
- Lighting adjustment

❌ NOT FIXABLE (Manual work required)
- Complex product replacement in scene
- Composition redesign
- Background rebuild
```

### 6.3 Fixing Workflow

```
ISSUE DETECTED (e.g., "Product color is navy, should be gold")
    ↓
ASSESS FIXABILITY
    ├─ Fixable? → Generate fix automatically
    └─ Not fixable? → Mark as manual only
    ↓
GENERATE FIX INSTRUCTIONS
    "Replace navy resin in product area (x,y,w,h) with gold"
    ↓
USE CLAUDE VISION + INPAINTING
    - Extract problem area
    - Generate corrected version
    - Blend back into image
    ↓
QUALITY CHECK
    - Verify fix improved issue
    - Check for new artifacts
    - Measure confidence
    ↓
PRESENT TO USER
    "Fix available: Product color corrected (+8 points to score)"
    [PREVIEW] [APPLY] [DECLINE]
```

### Prompt Structure

```javascript
const analysisPrompt = `
You are a creative quality assurance expert. Analyze this advertisement creative.

REFERENCE PRODUCT
[Image of actual product with context]

ADVERTISEMENT CREATIVE
[Image of AI-generated ad]

BRAND PROFILE
- Colors: ${brandProfile.colors}
- Typography: ${brandProfile.typography}
- Product rules: ${brandProfile.productRules}
- Visual style: ${brandProfile.visualStyle}

Analyze and respond with ONLY this JSON structure:
{
  "product_analysis": {
    "product_visible": boolean,
    "shape_match": 0-100,
    "color_match": 0-100,
    "logo_accurate": boolean,
    "packaging_correct": boolean,
    "distinguishing_features": [{name, present, accurate}],
    "issues": [{
      "feature": "string",
      "problem": "string",
      "confidence": 0-100
    }]
  },
  "brand_analysis": {
    "color_adherence": 0-100,
    "typography_match": 0-100,
    "visual_style_match": 0-100,
    "issues": [{title, description}]
  },
  "ai_quality": {
    "texture_natural": 0-100,
    "geometry_valid": 0-100,
    "lighting_realistic": 0-100,
    "artifacts_detected": [{type, location, severity}]
  },
  "readability": {
    "text_contrast": 0-100,
    "mobile_readable": boolean,
    "cta_prominent": boolean,
    "issues": [{type, description}]
  },
  "overall_assessment": "ready" | "review_needed" | "reject",
  "fixable_issues": [{
    "issue_id": UUID,
    "fixable": boolean,
    "fix_method": "color_correction" | "product_swap" | "blur_removal" | "text_enhance",
    "fix_instructions": "Replace navy resin in bounding box with gold",
    "estimated_quality": 0-100
  }]
}
`;

// FIXING PROMPT
const fixingPrompt = `
You are a creative image fixing specialist.

ISSUE TO FIX
Title: ${issue.title}
Description: ${issue.description}
Location: ${issue.location} (bounding box)

ORIGINAL IMAGE
[Image]

REFERENCE
[Product reference or brand color swatch]

Generate a fixed version where:
${fixInstructions}

Rules:
- Only modify the identified problem area
- Maintain natural lighting and shadows
- Preserve overall image composition
- Ensure fix doesn't create new artifacts

Return ONLY:
{
  "fixed_image": base64_png,
  "quality_score": 0-100,
  "artifacts_introduced": []
}
`;
```

---

## 7. DATA FLOW

### Step-by-Step Analysis Pipeline

```
1. User uploads creative + selects brand/references
         ↓
2. File validation & S3 storage
         ↓
3. Queue analysis job (Bull queue)
         ↓
4. Extract image metadata
         ↓
5. Call Claude Vision API with:
   - Creative image
   - Product reference images
   - Brand profile rules
         ↓
6. Parse Vision response → Extract scores
         ↓
7. Calculate composite scores (weighted)
         ↓
8. Determine READY_TO_PUBLISH status
         ↓
9. Store in PostgreSQL
         ↓
10. Update Redis cache
         ↓
11. Send webhook (if provided)
         ↓
12. Return to frontend with full report
```

---

## 8. PERFORMANCE & SCALING

### Optimization

```
- Redis caching for brand profiles (TTL: 24h)
- Image compression before S3 upload (max 2MB)
- Claude Vision batch processing for multiple creatives
- Database indexes on workspace_id, created_at, status
- CDN for serving reports/images
```

### Limits (MVP)

```
Free:       5 checks/month
Designer:   100 checks/month
Agency:     500 checks/month
Enterprise: Unlimited
```

---

## 9. UI/UX DIRECTION

### Design Philosophy

**NOT**: Flashy, "AI-style", gradient-heavy, glowy buttons

**YES**: 
- Clean, minimal, high-contrast
- Utilitarian (Figma, Stripe, Linear style)
- Clear hierarchy
- White/near-white background
- Strong typography
- Subtle, purposeful UI elements
- Status indicators (red/amber/green) as primary visual language
- Generous whitespace

### Color Palette

```
Background:    #FFFFFF (main), #F9F9F9 (secondary)
Text:          #1A1A1A (primary), #666666 (secondary)
Status Red:    #DC2626 (critical issues)
Status Amber:  #EA8E1A (warnings)
Status Green:  #16A34A (ready)
Border:        #E5E5E5
Accent:        #000000 (for interactive elements, minimal use)
```

### Typography

```
Headlines:     Inter 600/700, 20-32px
Body:          Inter 400, 14-16px
Mono:          JetBrains Mono (for technical data)
Line height:   1.5x for body text
Letter space:  -0.01em for headlines
```

### Component Rules

```
Buttons:
- Primary: Black text on white, 1px border #000
- Danger: Red background (#DC2626), white text
- Secondary: Gray (#F9F9F9) background, black text

Cards:
- 1px border #E5E5E5
- 0px shadow (never)
- 12px border-radius
- 16px padding

Inputs:
- 1px border #E5E5E5
- Focus: 2px solid #000
- Placeholder: #999
- 8px padding

Status badges:
- Red: #FEE2E2 background, #991B1B text
- Amber: #FEF3C7 background, #92400E text
- Green: #DCFCE7 background, #166534 text
```

### Screens to Build (9 core flows)

```
1. Dashboard
   - User workspace overview
   - Recent checks (table: name, score, status, date)
   - Quick stats (checks used this month, % ready-to-publish, fixes applied)
   - No charts, no flashiness
   
2. New Check (Upload flow)
   - Two dropzones: product reference + creative
   - Campaign selector
   - Brand profile selector
   - Single "ANALYZE" button
   
3. Analysis (Loading state)
   - Progress indicator (text-based, not animated)
   - "Analyzing your creative..."
   - Estimated time: 10-30 seconds
   
4. Results (Hero screen)
   - Left: Creative image thumbnail
   - Right: Score card
     * CREATIVE READY SCORE (large, 84/100)
     * 5 component scores (bars or simple numbers)
     * Ready/Don't Publish status
   - Issues section below (list view)
   
5. Issues Detail
   - Each issue: icon, title, description, confidence %, location indicator
   - Badge showing if fixable or not
   - Collapsible "Why this matters"
   - [FIX THIS ISSUE] button if fixable
   
6. Fix Preview
   - Shows which issues are fixable
   - List view: "Product color – FIXABLE"
   - Estimate total time + impact on score
   - [FIX ALL] or select individual fixes
   - "Estimated new score: 91/100"
   
7. Fix Processing
   - Progress: "Fixing product color..."
   - Real-time status updates
   - Each fix shows before/during/after
   
8. Brand Kit
   - Brand profile editor
   - Logo upload
   - Color palette input
   - Typography rules
   - Product guidelines checklist
   
9. Product Library
   - Add/manage product references
   - Bulk upload reference images
   - View extracted product DNA
   
10. Before/After
    - Side-by-side comparison
    - Original vs. Fixed creative
    - Reference image vs. creative image
    - Highlight corrected areas
    - [APPROVE & USE] button
```

---

## 10. MVP FEATURE BREAKDOWN

### Phase 1 (Weeks 1-4)
```
✅ User auth (signup/login/API key)
✅ Workspace creation
✅ File upload (S3 integration)
✅ Brand profile CRUD
✅ Product reference upload
✅ Claude Vision analysis pipeline
✅ Score calculation
✅ Basic creative check storage
✅ Dashboard + results view
```

### Phase 2 (Weeks 5-8)
```
✅ Issue categorization + severity
✅ Ready/Don't Publish determination
✅ Brand rules engine
✅ Compliance checks
✅ Mobile readability analysis
✅ Before/after comparison view
✅ Check history
✅ Simple reporting
✅ IMAGE FIXING (core methods)
   - Color correction (product, logo, brand colors)
   - Text/readability enhancement
   - AI artifact blur removal
   - Product replacement (swap with reference)
✅ Fix preview + quality validation
✅ Fix processing UI
```

### Phase 3 (Weeks 9-12)
```
✅ Team/workspace management
✅ Billing integration (Stripe)
✅ Usage tracking
✅ Webhooks for analysis + fix completion
✅ API documentation
✅ Basic Figma plugin (read-only initial)
✅ Download fixed creative (PNG + metadata)
```

### Post-MVP (Not building yet)
```
❌ Batch analysis (multi-file processing)
❌ Video analysis/fixing
❌ Advanced Figma plugin (with in-editor checks & fixes)
❌ White-label
❌ Advanced analytics dashboard
❌ A/B testing suite
```

---

## 11. TECH DECISIONS & RATIONALE

| Decision | Why |
|----------|-----|
| Node.js + Express | Fast iteration, JavaScript full-stack, good for async |
| PostgreSQL | Relational data (users, brands, checks), mature, reliable |
| Redis | Fast caching, Bull for job queue, rate limiting |
| Claude Vision | SOTA multimodal analysis, no need to fine-tune |
| S3 | Scalable, cheap, industry standard |
| JWT + API keys | Standard auth, easy to scale |
| No frameworks (yet) | Keep MVP lean, add Next.js/React later if needed |
| Docker | Consistent deployment, easy scaling |

---

## 12. SECURITY & COMPLIANCE

```
🔒 Encryption
   - TLS 1.3 for all network traffic
   - API keys hashed with bcrypt
   - Passwords hashed with argon2

🔒 Data Privacy
   - Uploaded images deleted after 30 days (configurable)
   - No image sharing between customers
   - Workspace isolation (SQL-level)

🔒 Rate Limiting
   - 60 requests/minute per API key
   - Burst limit: 10 concurrent analyses

🔒 Audit Logging
   - Log all brand profile changes
   - Log user access
   - Retain for 90 days
```

---

## 13. DEPLOYMENT

### Local Development
```bash
# .env
DATABASE_URL=postgresql://localhost/creativecheck
REDIS_URL=redis://localhost:6379
AWS_ACCESS_KEY_ID=xxx
AWS_SECRET_ACCESS_KEY=xxx
ANTHROPIC_API_KEY=xxx
NODE_ENV=development
```

### Production
```
- PostgreSQL (RDS)
- Redis (ElastiCache or managed)
- Docker image on ECR
- Deploy to ECS / Railway / Render
- GitHub Actions CI/CD
- Monitoring: Sentry (errors), DataDog (logs)
```

---

## 14. COST ESTIMATES (First Year)

```
PostgreSQL (RDS):           ~$200/month
Redis (ElastiCache):        ~$50/month
S3 (storage + transfer):    ~$100/month
Claude API (analysis):      $0.001 per check × 500/month avg = ~$5/month
Compute (ECS/Render):       ~$150/month
Monitoring/Logging:         ~$100/month
Domain + SSL:               ~$20/month
Support/misc:               ~$50/month
                            ─────────────
TOTAL:                      ~$675/month
```

If you charge $15/mo × 50 users + $49/mo × 10 agencies = $1,240/mo revenue, you break even at ~65 paid users.

---

## 15. NEXT STEPS

1. **Backend setup** (Week 1-2)
   - PostgreSQL schema
   - Express server scaffold
   - Auth endpoints
   - File upload service

2. **Vision AI pipeline** (Week 2-4)
   - Claude Vision integration
   - Scoring algorithms
   - Queue system

3. **Figma UI specs** (Parallel with backend)
   - 8 core screens
   - Component library
   - Interaction specs

4. **Frontend** (Week 5-8)
   - React/Next.js setup
   - Connect to backend API
   - Authentication flow
   - Dashboard + check flow

5. **Testing & polish** (Week 9-12)
   - End-to-end testing
   - Performance optimization
   - Security audit
   - Launch prep
