# VERITY — Complete Product Overview

**Product Name**: VERITY  
**Tagline**: "Ensure your AI ads show the real product"  
**Status**: Ready to build (MVP Phase)  
**Timeline**: 12 weeks  
**Team Required**: 1 Designer (you) + 1-2 Backend Engineers + 1 Frontend Engineer

---

## EXECUTIVE SUMMARY

VERITY is a pre-flight quality assurance platform for AI-generated advertisements. It analyzes whether your AI-created ads accurately represent your real product, provides an easy-to-understand readiness score, identifies specific issues, and automatically fixes what it can.

**Who it's for**: Freelance designers, small creative agencies, e-commerce brands, jewelry/fashion brands using AI ad generation.

**Why it matters**: As AI image generation becomes standard for ad creation, brands need assurance that AI-generated products actually look like the real thing. VERITY solves that in 30 seconds.

**Key differentiation**: 
- Not an ad generator (checks after creation)
- Not a generic "is this good?" tool (specific product accuracy focus)
- Not just detecting (also fixing automatically)
- Built for agencies + designers, not enterprises

---

## PRODUCT POSITIONING

### The Problem
Designers & agencies are using AI tools to generate ads 10x faster. But:
- ❌ AI hallucinations: Products look wrong (color, logo, shape)
- ❌ Manual QA: Someone has to review each creative anyway
- ❌ No objective standard: "Is this close enough?" is subjective
- ❌ Time waste: Find issues after publishing, then redo everything

### The Solution (VERITY)
Upload your AI ad + product photos. VERITY:
1. Checks if product is accurate (vs real reference)
2. Validates brand consistency (colors, logo, style)
3. Detects AI artifacts & readability issues
4. Gives you a READY/DON'T PUBLISH decision
5. Auto-fixes what's fixable
6. Lets you download the corrected version

### Time Saved Per Creative
- Manual QA: 5-10 minutes per ad
- VERITY: 30 seconds analysis + fixes

For an agency generating 50 ads/week: **4-8 hours saved per week**.

---

## COMPLETE FEATURE SET (MVP)

### Core: Creative Analysis

```
Input:
├─ AI-generated ad (image)
├─ Product reference photos (1-5)
└─ Brand profile (colors, rules, style)

Output:
├─ CREATIVE READY SCORE (0-100)
│  ├─ Product Accuracy (35%)
│  ├─ Brand Consistency (25%)
│  ├─ AI Quality (15%)
│  ├─ Readability (15%)
│  └─ Compliance (10%)
├─ READY / DON'T PUBLISH badge
├─ Issue list (with severity)
│  ├─ 🔴 Critical (red)
│  ├─ 🟠 Warning (amber)
│  └─ 🟡 Info (yellow)
└─ Fixable issues indicator
```

### Feature 2: Automatic Fixing

```
For fixable issues:
├─ Color correction (product, logo, brand colors)
├─ Text enhancement (readability, contrast)
├─ AI artifact removal (blur, smooth distortions)
└─ Product replacement (swap with reference)

Workflow:
1. Show preview (what's fixable + estimated time)
2. User approves fixes
3. Processing (real-time status)
4. Results (before/after comparison)
5. Download fixed version
```

### Feature 3: Brand Management

```
Brand Profile Creation:
├─ Logo upload
├─ Color palette (primary, secondary, accents)
├─ Typography rules (headline, body fonts)
├─ Product rules (material, finish, dimensions)
├─ Visual style (premium/minimal/bold/warm/etc)
└─ Compliance rules (disclaimers, claims, etc)

Reusable Across Checks:
└─ Every creative checked against same brand rules
```

### Feature 4: Product Library

```
Product Reference Management:
├─ Upload 1-5 photos per product variant
├─ Vision AI extracts "Product DNA"
│  ├─ Shape & silhouette
│  ├─ Color palette
│  ├─ Materials & finish
│  ├─ Logo details
│  └─ Distinguishing features
└─ Reuse across all future checks
```

### Feature 5: Dashboard & History

```
Dashboard shows:
├─ Recent checks (score, status, date)
├─ Monthly usage (checks used, % ready-to-publish)
├─ Last check status
└─ Quick access to projects & brand kits

Check History:
├─ List all past analyses
├─ Filter by project, score, status
├─ Compare before/after versions
└─ Re-run analysis on same creative
```

### Feature 6: Reporting

```
Report per creative includes:
├─ Score breakdown (visual + numeric)
├─ All issues found (with confidence %)
├─ Before/after comparison (if fixes applied)
├─ Download as PDF
└─ Share link (read-only, expiring)
```

---

## WHAT WE'RE NOT BUILDING (YET)

❌ **Image generation** (use DALL-E, Midjourney, etc.)  
❌ **Video analysis** (Phase 2+)  
❌ **Batch processing** (100+ creatives at once) (Phase 2+)  
❌ **Advanced Figma plugin** (Phase 3+)  
❌ **A/B testing suite** (Post-MVP)  
❌ **White-label** (Post-MVP)  

This keeps MVP lean and launchable in 12 weeks.

---

## 10 CORE SCREENS

| Screen | Purpose | User Action |
|--------|---------|---|
| 1. Dashboard | Workspace overview, recent checks | View history, start new check |
| 2. New Check - Upload | Drag & drop product refs + creative | Choose brand, initiate analysis |
| 3. Analysis | Loading state, progress updates | Wait 20-30 seconds |
| 4. Results (Hero) | Score card + issue summary | View details or start fixes |
| 5. Issues Detail | Expandable list of all issues | Mark as reviewed or fix individual |
| 6. Fix Preview | What's fixable + estimated improvement | Approve or skip fixes |
| 7. Fix Processing | Real-time fix status | Watch progress |
| 8. Fix Results | Before/after + fixes applied | Approve & use fixed version |
| 9. Brand Kit | Create/edit brand profile | Build or update brand rules |
| 10. Product Library | Manage product references | Upload product photos |

**Design Time**: 2-3 weeks (Figma prototype)  
**Interaction Specs**: Built into Figma, ready for handoff to frontend

---

## TECHNICAL ARCHITECTURE

### Backend Stack
- **Language**: Node.js + Express.js
- **Database**: PostgreSQL (users, brands, checks)
- **Cache**: Redis (brand profiles, recent checks)
- **Jobs**: Bull queue (async analysis pipeline)
- **Vision AI**: Claude Vision API (multimodal analysis)
- **Storage**: AWS S3 (images)
- **Auth**: JWT + API keys

### Key Services
```
Auth Service       → Signup/login/API key management
Upload Service    → File validation, S3 storage
Analysis Service  → Claude Vision orchestration + scoring
Brand Service     → Brand profile CRUD
Check Service     → Store/retrieve analyses
Fix Service       → Image correction + quality validation
Webhook Service   → Async notifications
```

### Analysis Pipeline
```
1. User uploads creative + references
2. Files validated & stored in S3
3. Job queued in Bull
4. Claude Vision analyzes (get product features, detect issues)
5. Calculate scores (weighted algorithm)
6. Determine READY/DON'T PUBLISH
7. Store in PostgreSQL
8. Send webhook + return to UI
Total time: 10-30 seconds
```

### Fixing Pipeline
```
1. User requests fixes for selected issues
2. Show preview (fixable issues + time estimate)
3. User approves
4. For each fixable issue:
   a. Extract problem area from image
   b. Call Claude Vision with fix instructions
   c. Blend corrected area back into image
   d. Quality check (did it improve the score?)
5. Store fixed image + metadata
6. Return before/after comparison
Total time per fix: 5-15 seconds
```

---

## DATABASE SCHEMA (Key Tables)

```
users
├─ id, email, password_hash, workspace_id

workspaces
├─ id, name, owner_id, plan, monthly_checks_used/limit

brand_profiles
├─ id, workspace_id, name, colors, typography
├─ product_rules, visual_style, brand_dna

product_references
├─ id, brand_id, product_name, reference_images
├─ product_dna (extracted: shape, color, materials, etc)

creative_checks
├─ id, workspace_id, brand_id
├─ creative_image_url, reference_image_ids
├─ status, creative_ready_score (0-100)
├─ product_accuracy, brand_consistency, ai_quality, etc
├─ issues (array: {type, severity, title, description})
├─ fixed_image_url, fixes_applied
└─ ready_to_publish (boolean)
```

---

## DESIGN SYSTEM

### Color Palette (Minimal, High Contrast)

```
Backgrounds:    #FFFFFF (main), #F9F9F9 (secondary)
Text:           #1A1A1A (primary), #666 (secondary)
Borders:        #E5E5E5

Status Colors:
🔴 Red:         #DC2626 (critical)
🟠 Amber:       #EA8E1A (warning)
🟢 Green:       #16A34A (ready)
```

### Typography (Clean, Utilitarian)

```
Font Family:    Inter (Google Fonts)
Headlines:      32px / 600 weight / -0.01em spacing
Body:           14-16px / 400 weight
Labels:         12px / 500 weight
Mono (data):    JetBrains Mono 13px
```

### Components (Simple, No Gradients)

```
Buttons:
├─ Primary:      Black bg, white text, 6px radius
├─ Secondary:    #F9F9F9 bg, 1px border
└─ Danger:       Red bg, white text

Cards:
├─ 1px border #E5E5E5
├─ 8px radius
├─ No shadow ever
└─ 20px padding

Inputs:
├─ 1px border #E5E5E5
├─ Focus: 2px solid #000
└─ 6px radius
```

### Visual Philosophy

**What we DO:**
✅ Clean white/gray backgrounds  
✅ Strong black text  
✅ Red/amber/green for status (primary visual language)  
✅ Generous whitespace  
✅ Feather icons (20px, outline only)  
✅ 6-8px border radius  
✅ 1px borders (never thick borders)  

**What we DON'T:**
❌ Gradients  
❌ Glow effects  
❌ Shadows  
❌ Animated spinners  
❌ Floating elements  
❌ Neon colors  
❌ Skeuomorphism  

**Inspiration Brands:**
- Figma (clean, purposeful)
- Stripe (minimal, high contrast)
- Linear (utilitarian, focused)
- GitHub (white/gray, strong type)

---

## MVP TIMELINE (12 Weeks)

### Phase 1: Foundation (Weeks 1-4)
**Backend + Auth + Upload**

Week 1-2:
- ✅ Express server scaffold
- ✅ PostgreSQL schema
- ✅ User auth (signup/login/API key)
- ✅ Workspace management

Week 3-4:
- ✅ File upload service (S3 integration)
- ✅ Image validation
- ✅ Brand profile CRUD
- ✅ Product reference upload

**Deliverable**: Backend API ready for first analysis endpoint

---

### Phase 2: Analysis & Fixing (Weeks 5-8)
**Vision AI + Scoring + Fixing**

Week 5:
- ✅ Claude Vision integration
- ✅ Analysis pipeline (queued jobs)
- ✅ Scoring algorithms (product accuracy, brand consistency, AI quality, readability, compliance)
- ✅ Issue detection & classification

Week 6-7:
- ✅ Auto-fix service (color correction, text enhancement, artifact removal, product swap)
- ✅ Fix preview + quality validation
- ✅ Before/after comparison generation
- ✅ Webhook notifications

Week 8:
- ✅ Testing & optimization
- ✅ API documentation

**Deliverable**: Full analysis + fixing pipeline working end-to-end

---

### Phase 3: Frontend (Weeks 5-8 parallel with Phase 2)
**React/Next.js + All 10 Screens**

Week 5-6:
- ✅ Figma design complete (10 screens + component specs)
- ✅ React project scaffold
- ✅ Component library (buttons, inputs, cards, badges)
- ✅ Dashboard + navigation

Week 7-8:
- ✅ Upload flow (drag & drop)
- ✅ Results screen (score card + issues)
- ✅ Fix flow (preview → processing → results)
- ✅ Brand kit editor
- ✅ Product library manager

**Deliverable**: Full UI working, connected to backend

---

### Phase 4: Polish & Launch (Weeks 9-12)
**Team, Billing, Monitoring**

Week 9:
- ✅ Team/workspace features
- ✅ Usage tracking & rate limiting
- ✅ Stripe billing integration

Week 10:
- ✅ Email notifications
- ✅ API key management
- ✅ Security audit
- ✅ Performance optimization

Week 11:
- ✅ Monitoring (Sentry, DataDog)
- ✅ QA testing
- ✅ Fix bugs

Week 12:
- ✅ Deploy to production
- ✅ Soft launch (beta users)
- ✅ Gather feedback

**Deliverable**: Live product, ready for users

---

## PRICING (MVP Launch)

```
Free Plan
├─ 5 checks/month
├─ 1 brand profile
├─ Basic brand kit
└─ Community support

Designer ($15/month)
├─ 100 checks/month
├─ 5 brand profiles
├─ Advanced brand rules
├─ Priority support
└─ API access

Agency ($49/month)
├─ 500 checks/month
├─ Unlimited brand profiles
├─ Team members (up to 5)
├─ Usage reports
├─ Email support
└─ API access

Enterprise (Custom)
├─ Unlimited checks
├─ Dedicated account manager
├─ SLA
└─ Custom integrations
```

**Strategy**: Get 50-100 paying users before raising prices.

---

## SUCCESS METRICS

### Launch Targets (Month 1)
- ✅ 100 beta signups
- ✅ 50+ active users
- ✅ 10+ paying customers
- ✅ 95%+ uptime
- ✅ < 2 min time to first check

### Year 1 Goals
- ✅ $50k ARR
- ✅ 1000+ users
- ✅ 100+ paid customers
- ✅ Net retention > 90%
- ✅ < 30s avg analysis time

---

## TEAM STRUCTURE

### Your Role: Product Designer
- **Weeks 1-3**: Figma design (10 screens, component library)
- **Weeks 4-8**: Frontend support (design QA, interaction specs)
- **Weeks 9-12**: Polish (edge cases, mobile, accessibility)
- **Ongoing**: Design updates, customer feedback integration

**Time commitment**: ~40 hrs/week

### Backend Engineer (1-2 needed)
- Database schema
- API endpoints
- Claude Vision integration
- Image fixing pipeline
- Deployment & monitoring

**Time commitment**: ~80 hrs/week total

### Frontend Engineer (1 needed)
- React/Next.js setup
- UI components
- Connect to backend API
- Mobile responsiveness
- Performance optimization

**Time commitment**: ~80 hrs/week

---

## WHAT TO BUILD FIRST (If Solo)

If you want to build this solo initially:

**Weeks 1-3: Figma Design**
- All 10 screens at high fidelity
- Component specs + interactions
- Ready to hand off to engineers

**Weeks 4-6: HTML Prototype** (optional, can skip)
- Clickable prototype in Framer or HTML
- Test flows with users
- Validate UX before engineering

**Week 7+: Find engineer partners**
- Post in dev communities
- Offer equity + revenue share
- Build together

**Cost to MVP**: $0 (your time) if you do design + prototype
**Cost if hiring**: ~$15-20k for freelance backend/frontend (12 weeks)

---

## NEXT IMMEDIATE STEPS

### Tomorrow:
1. ✅ Create Figma file (VERITY Design System)
2. ✅ Set up component library (colors, typography, buttons, cards)
3. ✅ Create frame for each of 10 screens

### This Week:
1. Design Dashboard screen (high fidelity)
2. Design New Check / Upload flow
3. Design Results (hero screen)

### Next Week:
1. Complete all 10 screens
2. Add interaction specs
3. Prepare for handoff to frontend

### Following Week:
1. Start recruiting backend engineer
2. Share Figma file + technical spec
3. Begin engineering

---

## FILES YOU NOW HAVE

```
✅ CreativeCheck_Technical_Spec.md
   → Complete backend spec, database schema, API, scoring logic

✅ Product_Name_Options.md
   → Why VERITY, domain strategy, positioning

✅ VERITY_UI_Specification.md
   → All 10 screens, design system, interactions, flows

This document (Product Overview)
   → Timeline, features, positioning, next steps
```

---

## FINAL THOUGHTS

**Why this will work:**

1. **Real problem**: Agencies already have this workflow (manual QA)
2. **Specific niche**: Not competing with generic "AI ad checker" tools
3. **Defensible**: Brand DNA moat + fixing capability
4. **Profitable**: Low CAC (designer/agency customers), recurring revenue
5. **Scalable**: API-first, will power future integrations (Figma plugin, email, etc)

**Timeline is aggressive but achievable**: 12 weeks to MVP if you find good engineers.

**Start with Figma design this week**: That's your unique value as a designer. Beautiful, functional UI + solid backend = product people want.

Ready?

